#pragma once
#include <Windows.h>
#include "resource.h"
#include "Chess.h"
using namespace sf;

#define WINDOW_WIDTH 1500
#define WINDOW_HEIGHT 732
#define BUTTON_WIDTH 213
#define BUTTON_HEIGHT 78
#define BUTTON_TURN_OFF_EDGE_LENTH 40
#define BUTTON_VOLUME_CHANGE_EDGE_LENTH 25
#define BUTTON_VOLUME_TURN_EDGE_LENTH 35
#define BUTTON_HOME_BACK_EDGE_LENTH 80
#define BUTTON_VOLUME_STRIPE_WIDTH 300
#define BUTTON_VOLUME_STRIPE_HEIGHT 20
#define BUTTON_VOLUME_SLIDER_WIDTH 10
#define BUTTON_VOLUME_SLIDER_HEIGHT 28
#define WINNER_WORD_WIDTH 344
#define WINNER_WORD_HEIGHT 114
#define SETTING_PAGE_BUTTON_WIDTH 160
#define SETTING_PAGE_BUTTON_HEIGHT 52
#define RULE_WIDTH 905
#define RULE_HEIGHT 2418
#define RULE_SHOW_HEIGHT 470
#define RECTANGLE_WIDTH 519
#define RECTANGLE_HEIGHT 142
#define BUTTON_GAMEPAGE_SCALE 0.73

#define BUTTON_LOCAL_START_X 170
#define BUTTON_LOCAL_START_Y 560
#define BUTTON_ONLINE_START_X 470
#define BUTTON_ONLINE_START_Y 560
#define BUTTON_STARTPAGE_EXIT_X 770
#define BUTTON_STARTPAGE_EXIT_Y 560
#define BUTTON_STARTPAGE_SETTING_X 1070
#define BUTTON_STARTPAGE_SETTING_Y 560
#define BUTTON_REGRET_X 905
#define BUTTON_REGRET_Y 627
#define BUTTON_TIE_X 1110
#define BUTTON_TIE_Y 627
#define BUTTON_SURRENDER_X 1315
#define BUTTON_SURRENDER_Y 627
#define BUTTON_GAMEPAGE_SETTING_X 1266
#define BUTTON_GAMEPAGE_SETTING_Y 16
#define BUTTON_RESTART_X 213
#define BUTTON_RESTART_Y 347
#define BUTTON_GAMEOVER_EXIT_X 585
#define BUTTON_GAMEOVER_EXIT_Y 347
#define BUTTON_YES_X 213
#define BUTTON_YES_Y 347
#define BUTTON_NO_X 585
#define BUTTON_NO_Y 347
#define BUTTON_TURN_OFF_X 920
#define BUTTON_TURN_OFF_Y 20
#define BUTTON_SETTING_PAGE_LOGIC_X 0
#define BUTTON_SETTING_PAGE_RULE_X 160
#define BUTTON_SETTING_PAGE_Y -52
#define BUTTON_SAVE_X 496
#define BUTTON_SAVE_Y 354
#define BUTTON_LOAD_X 178
#define BUTTON_LOAD_Y 354
#define BUTTON_HOME_X 833
#define BUTTON_HOME_Y 354
#define BUTTON_BACK_X 1319
#define BUTTON_BACK_Y 52
#define BUTTON_BGM_VOLUME_PLUS_X 742
#define BUTTON_BGM_VOLUME_PLUS_Y 120
#define BUTTON_BGM_VOLUME_SUBSTRUCT_X 343
#define BUTTON_BGM_VOLUME_SUBSTRUCT_Y 120
#define BUTTON_BGM_VOLUME_TURN_X 796
#define BUTTON_BGM_VOLUME_TURN_Y 115
#define BUTTON_SE_VOLUME_PLUS_X 742
#define BUTTON_SE_VOLUME_PLUS_Y 204
#define BUTTON_SE_VOLUME_SUBSTRUCT_X 343
#define BUTTON_SE_VOLUME_SUBSTRUCT_Y 204
#define BUTTON_SE_VOLUME_TURN_X 796
#define BUTTON_SE_VOLUME_TURN_Y 199
#define BUTTON_BGM_STRIPE_X 405
#define BUTTON_BGM_STRIPE_Y 122.5
#define BUTTON_BGM_SLIDER_Y 120
#define BUTTON_SE_STRIPE_X 405
#define BUTTON_SE_STRIPE_Y 206.5
#define BUTTON_SE_SLIDER_Y 204
#define SL_RECTANGLE_X_1 205
#define SL_RECTANGLE_X_2 784
#define SL_RECTANGLE_Y_1 215
#define SL_RECTANGLE_Y_2 375
#define SL_RECTANGLE_Y_3 535
#define POP_WINDOW_X 267
#define POP_WINDOW_Y 92
#define BIG_POP_WINDOW_X 0
#define BIG_POP_WINDOW_Y 0
#define RULE_POS_X 52
#define RULE_POS_Y 30

#define DEATH_PIECE_MARQUEE_X 1073
#define DEATH_PIECE_MARQUEE_Y 266
#define DEATH_PIECE_1_X 1179
#define DEATH_PIECE_2_FIRST_X 1144
#define DEATH_PIECE_2_SECOND_X 1214
#define DEATH_PIECE_Y 319

#define BLOC_WORD_X 562
#define BLOC_WORD_Y 590
#define LAST_DEATH_WORD_X 1066
#define LAST_DEATH_WORD_Y 182
#define PIECE_TAKER_WORD_X 78
#define PIECE_TAKER_WORD_Y 595
#define WINNER_WORD_X 321
#define WINNER_WORD_Y 101
#define TIE_WORD_X 382
#define TIE_WORD_Y 101
#define ACCEPT_RETRACT_WORD_X 109
#define ACCEPT_RETRACT_WORD_Y 119
#define ACCEPT_TIE_WORD_X 109
#define ACCEPT_TIE_WORD_Y 119
#define TO_SURRENDER_WORD_X 130
#define TO_SURRENDER_WORD_Y 119
#define BACK_HOME_WORD_X 291
#define BACK_HOME_WORD_Y 132
#define COVER_FILE_WORD_X 284
#define COVER_FILE_WORD_Y 128
#define BGM_WORD_X 97
#define BGM_WORD_Y 109
#define SE_WORD_X 97
#define SE_WORD_Y 193
#define BGM_VOLUME_VALUE_X 858
#define BGM_VOLUME_VALUE_Y 107
#define SE_VOLUME_VALUE_X 858
#define SE_VOLUME_VALUE_Y 191
#define SL_WORD_X 110
#define SL_WORD_Y 63
#define SL_DETAIL_WORD_X_IN_RECTANGLE 31
#define SL_DETAIL_WORD_Y_IN_RECTANGLE 22
#define SL_TIME_WORD_X_IN_RECTANGLE 487
#define SL_TIME_WORD_Y_IN_RECTANGLE 115

typedef enum GAME_STATE
{
	START_PAGE = 1,
	GAME_PAGE,
	GAME_PAUSED_PAGE,
	SAVE_PAGE,
	LOAD_PAGE,
	GAME_OVER_PAGE
};

typedef enum PIECE_STATE
{
	WAIT_4_NONE,
	WAIT_4_OPEN,
	WAIT_4_ATTACK
};

typedef enum LAST_CLICK_STATE
{
	PIECE,
	REGRET_BUTTON,
	TIE_BUTTON,
	SURRENDER_BUTTON,
	HOME_BUTTON,
	BACK_BUTTON,
	SETTING_BUTTON_FROM_START_PAGE,
	SETTING_BUTTON_FROM_GAME_PAGE,
};

typedef enum SETTING_PAGE
{
	SETTING_PAGE_LOGIC,
	SETTING_PAGE_RULE
};

class Game
{
public:
	Game() {
		window_width = WINDOW_WIDTH;
		window_height = WINDOW_HEIGHT;

		window.create(VideoMode(window_width, window_height), L"FFXQ by ��㿩", Style::Titlebar | Style::Close);

		HINSTANCE hInstance = ::GetModuleHandle(NULL);
		HICON hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPICON));
		HWND hWnd = FindWindowExW(NULL, NULL, NULL, L"FFXQ by ��㿩");
		::SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
		::SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);

		window.setFramerateLimit(60);
	};
	~Game() {};

	RenderWindow window;
	Chess chess;
	Chess formerChess;
	bool gameOver, gameQuit, yesClicked, noClicked, BGMSliderClicked, SESliderClicked;
	Vector2i clickedPos, originPos;
	int window_width, window_height;
	int gameState, gameOverState, lastClickState, settingPage;
	int ruleAdjustment;
	Texture tBackground, tStartPage, tDeathPieceMarquee, tPopWindow, tVolumeStripeSlider, tRule, tBigPopWindow, tRectangle;
	Texture tButtons, tTurnOffButton, tSettingPageButton, tVolumeChangeButton, tVolumeTurnButton, tBackHomeButton;
	Texture tBlackBlocWord, tRedBlocWord, tUnknownBlocWord, tPieceTakerWord, tLastDeathWord, tWinnerWord, tAcceptRetractWord, tAcceptTieWord, tToSurrenderWord, tBackHomeWord, tCoverFileWord, tBGMWord, tSEWord, tSaveWord, tLoadWord;
	Sprite spBackground, spStartPage, spDeathPieceMarquee, spPopWindow, spVolumeStripeSlider, spRule, spBigPopWindow, spRectangle;
	Sprite spButtons, spTurnOffButton, spSettingPageButton, spVolumeChangeButton, spVolumeTurnButton, spBackHomeButton, spVolumeSliderButton;
	Sprite spBlocWord, spPieceTakerWord, spLastDeathWord, spWinnerWord, spAcceptWord, spBackHomeWord, spCoverFileWord, spBGMWord, spSEWord, spSaveWord, spLoadWord;
	IntRect ButtonRectLocalStart, ButtonRectOnlineStart, ButtonRectExit, ButtonRectSetting, ButtonRectRegret, ButtonRectTie, ButtonRectSurrender, ButtonRectRestart, ButtonRectYes, ButtonRectNo, ButtonRectSave, ButtonRectLoad;
	IntRect ButtonRectTurnOff, ButtonRectSettingPageLogic, ButtonRectSettingPageRule, ButtonRectBGMVolumePlus, ButtonRectBGMVolumeSubstruct, ButtonRectSEVolumePlus, ButtonRectSEVolumeSubstruct, ButtonRectBGMVolumeTurn, ButtonRectSEVolumeTurn, ButtonRectHome, ButtonRectBack;
	IntRect ButtonRectBGMSlider, ButtonRectBGMStripe, ButtonRectSESlider, ButtonRectSEStripe;
	IntRect ButtonRectSLOne, ButtonRectSLTwo, ButtonRectSLThree, ButtonRectSLFour, ButtonRectSLFive, ButtonRectSLSix;
	Music StartPageBKMusic, GamePageBKMusic;
	Sound soundButton, soundPiece, soundWrongPiece;
	SoundBuffer sbButton, sbPiece, sbWrongPiece;
	Font font;
	Text text;
	FloatRect fRect;

	float musicVolume, soundVolume;
	bool isMusicOn, isSoundOn;

	std::ifstream in;
	std::ofstream out;
	SYSTEMTIME sysTime;

	void save(std::string fileName);
	void load(std::string fileName);
	void loadMediaData();
	void drawSingleButton(Sprite* spButton, IntRect* ButtonRect, int grid_x, int grid_y, int button_position_x, int button_position_y, int button_width, int button_height);
	void drawButtons(int GS);
	void drawPiece();
	void drawSaveWord(std::string s, int saveWordPosX, int saveWordPosY, int saveTimePosX, int saveTimePosY);
	void gamePageDraw();

	void gameInit();
	void gameInput();
	void gameLogic();
	void gameDraw();
	void gameRun();
};

void Game::save(std::string fileName)
{
	GetLocalTime(&sysTime);
	out.open(fileName);
	
	out << sysTime.wYear << " " << sysTime.wMonth << " " << sysTime.wDay << std::endl;
	out << sysTime.wHour << " " << sysTime.wMinute << " " << sysTime.wSecond << std::endl;

	for (int i = 0; i < 32; i++)
	{
		out << chess.piece[i].bloc << " " << chess.piece[i].pieceType << std::endl;
		out << chess.piece[i].piecePosition.x << " " << chess.piece[i].piecePosition.y << std::endl;
		out << chess.piece[i].isOpened << " " << chess.piece[i].isDeath << std::endl;
	}

	for (int i = 0; i < 2; i++)
	{
		out << chess.lastDeadPiece[i].bloc << " " << chess.lastDeadPiece[i].pieceType << std::endl;
		out << chess.lastDeadPiece[i].piecePosition.x << " " << chess.piece[i].piecePosition.y << std::endl;
		out << chess.lastDeadPiece[i].isOpened << " " << chess.lastDeadPiece[i].isDeath << std::endl;
	}

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 4; j++)
		{
			out << chess.cb.isPiecePosUsed[i][j] << " ";
		}
	out << std::endl;

	out << chess.bloc << std::endl;

	out << chess.firstClick << " " << chess.secondClick << std::endl;
	out << chess.firstOpen << " " << chess.isClicked << std::endl;

	out << chess.chosenPos.x << " " << chess.chosenPos.y << std::endl;
	out << chess.chosenPos2.x << " " << chess.chosenPos.y << std::endl;
	out << chess.stepBeforeChosenPos.x << " " << chess.stepBeforeChosenPos.y << std::endl;

	out << chess.pieceState << std::endl;
	out << chess.lastDeadPieceNum << std::endl;

	out << chess.redPrice.blocPrice << " " << chess.redPrice.blocCannonNum << std::endl;
	out << chess.blackPrice.blocPrice << " " << chess.blackPrice.blocCannonNum << std::endl;

	for (int i = 0; i < 32; i++)
	{
		out << formerChess.piece[i].bloc << " " << formerChess.piece[i].pieceType << std::endl;
		out << formerChess.piece[i].piecePosition.x << " " << formerChess.piece[i].piecePosition.y << std::endl;
		out << formerChess.piece[i].isOpened << " " << formerChess.piece[i].isDeath << std::endl;
	}

	for (int i = 0; i < 2; i++)
	{
		out << formerChess.lastDeadPiece[i].bloc << " " << formerChess.lastDeadPiece[i].pieceType << std::endl;
		out << formerChess.lastDeadPiece[i].piecePosition.x << " " << formerChess.piece[i].piecePosition.y << std::endl;
		out << formerChess.lastDeadPiece[i].isOpened << " " << formerChess.lastDeadPiece[i].isDeath << std::endl;
	}

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 4; j++)
		{
			out << formerChess.cb.isPiecePosUsed[i][j] << " ";
		}
	out << std::endl;

	out << formerChess.bloc << std::endl;

	out << formerChess.firstClick << " " << formerChess.secondClick << std::endl;
	out << formerChess.firstOpen << " " << formerChess.isClicked << std::endl;

	out << formerChess.chosenPos.x << " " << formerChess.chosenPos.y << std::endl;
	out << formerChess.chosenPos2.x << " " << formerChess.chosenPos.y << std::endl;
	out << formerChess.stepBeforeChosenPos.x << " " << formerChess.stepBeforeChosenPos.y << std::endl;

	out << formerChess.pieceState << std::endl;
	out << formerChess.lastDeadPieceNum << std::endl;

	out << formerChess.redPrice.blocPrice << " " << formerChess.redPrice.blocCannonNum << std::endl;
	out << formerChess.blackPrice.blocPrice << " " << formerChess.blackPrice.blocCannonNum << std::endl;
	
	out.close();
}

void Game::load(std::string fileName)
{
	in.open(fileName);

	chess.initPiece();
	formerChess.initPiece();

	in >> sysTime.wYear >> sysTime.wMonth >> sysTime.wDay;
	in >> sysTime.wHour >> sysTime.wMinute >> sysTime.wSecond;

	for (int i = 0; i < 32; i++)
	{
		in >> chess.piece[i].bloc >> chess.piece[i].pieceType;
		in >> chess.piece[i].piecePosition.x >> chess.piece[i].piecePosition.y;
		in >> chess.piece[i].isOpened >> chess.piece[i].isDeath;
	}

	for (int i = 0; i < 2; i++)
	{
		in >> chess.lastDeadPiece[i].bloc >> chess.lastDeadPiece[i].pieceType;
		in >> chess.lastDeadPiece[i].piecePosition.x >> chess.piece[i].piecePosition.y;
		in >> chess.lastDeadPiece[i].isOpened >> chess.lastDeadPiece[i].isDeath;
	}

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 4; j++)
		{
			in >> chess.cb.isPiecePosUsed[i][j];
		}

	in >> chess.bloc;

	in >> chess.firstClick >> chess.secondClick;
	in >> chess.firstOpen >> chess.isClicked;

	in >> chess.chosenPos.x >> chess.chosenPos.y;
	in >> chess.chosenPos2.x >> chess.chosenPos.y;
	in >> chess.stepBeforeChosenPos.x >> chess.stepBeforeChosenPos.y;

	in >> chess.pieceState;
	in >> chess.lastDeadPieceNum;

	in >> chess.redPrice.blocPrice >> chess.redPrice.blocCannonNum;
	in >> chess.blackPrice.blocPrice >> chess.blackPrice.blocCannonNum;

	for (int i = 0; i < 32; i++)
	{
		in >> formerChess.piece[i].bloc >> formerChess.piece[i].pieceType;
		in >> formerChess.piece[i].piecePosition.x >> formerChess.piece[i].piecePosition.y;
		in >> formerChess.piece[i].isOpened >> formerChess.piece[i].isDeath;
	}

	for (int i = 0; i < 2; i++)
	{
		in >> formerChess.lastDeadPiece[i].bloc >> formerChess.lastDeadPiece[i].pieceType;
		in >> formerChess.lastDeadPiece[i].piecePosition.x >> formerChess.piece[i].piecePosition.y;
		in >> formerChess.lastDeadPiece[i].isOpened >> formerChess.lastDeadPiece[i].isDeath;
	}

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 4; j++)
		{
			in >> formerChess.cb.isPiecePosUsed[i][j];
		}

	in >> formerChess.bloc;

	in >> formerChess.firstClick >> formerChess.secondClick;
	in >> formerChess.firstOpen >> formerChess.isClicked;

	in >> formerChess.chosenPos.x >> formerChess.chosenPos.y;
	in >> formerChess.chosenPos2.x >> formerChess.chosenPos.y;
	in >> formerChess.stepBeforeChosenPos.x >> formerChess.stepBeforeChosenPos.y;

	in >> formerChess.pieceState;
	in >> formerChess.lastDeadPieceNum;

	in >> formerChess.redPrice.blocPrice >> formerChess.redPrice.blocCannonNum;
	in >> formerChess.blackPrice.blocPrice >> formerChess.blackPrice.blocCannonNum;

	for (int i = 0; i < 32; i++)
	{
		if (chess.piece[i].isDeath)
			continue;

		if (chess.piece[i].piecePosition == chess.chosenPos)
		{
			chess.Attacker = &chess.piece[i];
			break;
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (chess.piece[i].isDeath)
			continue;

		if (chess.piece[i].piecePosition == chess.chosenPos2)
		{
			chess.Defencer = &chess.piece[i];
			break;
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (chess.piece[i].isDeath)
			continue;

		if (chess.piece[i].piecePosition == chess.stepBeforeChosenPos)
		{
			chess.stepBeforeAttacker = &chess.piece[i];
			break;
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (formerChess.piece[i].isDeath)
			continue;

		if (formerChess.piece[i].piecePosition == formerChess.chosenPos)
		{
			formerChess.Attacker = &formerChess.piece[i];
			break;
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (formerChess.piece[i].isDeath)
			continue;

		if (formerChess.piece[i].piecePosition == formerChess.chosenPos2)
		{
			formerChess.Defencer = &formerChess.piece[i];
			break;
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (formerChess.piece[i].isDeath)
			continue;

		if (formerChess.piece[i].piecePosition == formerChess.chosenPos)
		{
			formerChess.Attacker = &formerChess.piece[i];
			break;
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (formerChess.piece[i].isDeath)
			continue;

		if (formerChess.piece[i].piecePosition == formerChess.stepBeforeChosenPos)
		{
			formerChess.stepBeforeAttacker = &formerChess.piece[i];
			break;
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (chess.piece[i].isOpened)
		{
			chess.piece[i].pieceOpen(&chess.tPiece);
		}
		else
		{
			chess.piece[i].spPiece.setTexture(chess.tUnturnedPiece);
			chess.piece[i].spPiece.setTextureRect(IntRect(0, 0, PIECE_EDGE_LENTH, PIECE_EDGE_LENTH));
		}
	}

	for (int i = 0; i < 32; i++)
	{
		if (formerChess.piece[i].isOpened)
		{
			formerChess.piece[i].pieceOpen(&formerChess.tPiece);
		}
		else
		{
			formerChess.piece[i].spPiece.setTexture(formerChess.tUnturnedPiece);
			formerChess.piece[i].spPiece.setTextureRect(IntRect(0, 0, PIECE_EDGE_LENTH, PIECE_EDGE_LENTH));
		}
	}

	in.close();
}

void Game::loadMediaData()
{
	tBackground.loadFromFile("./data/images/chessboard.png");
	tStartPage.loadFromFile("./data/images/startpage.png");
	tDeathPieceMarquee.loadFromFile("./data/images/death piece marquee.png");
	tPopWindow.loadFromFile("./data/images/pop window.png");
	tVolumeStripeSlider.loadFromFile("./data/images/Volume Stripe.png");
	tRule.loadFromFile("./data/images/rule.png");
	tBigPopWindow.loadFromFile("./data/images/big pop window.png");
	tRectangle.loadFromFile("./data/images/rectangle.png");

	tButtons.loadFromFile("./data/images/buttons.png");

	if (!tTurnOffButton.loadFromFile("./data/images/turn off.png"))
		std::cout << "��ƨŶ��turn off.png�Ҳ�������" << std::endl;

	if (!tSettingPageButton.loadFromFile("./data/images/Setting Page.png"))
		std::cout << "��ƨŶ��Setting Page.png�Ҳ�������" << std::endl;

	if (!tVolumeChangeButton.loadFromFile("./data/images/plus substruct.png"))
		std::cout << "��ƨŶ��plus substruct.png�Ҳ�������" << std::endl;

	if (!tVolumeTurnButton.loadFromFile("./data/images/isMusicOn.png"))
		std::cout << "��ƨŶ��isMusicOn.png�Ҳ�������" << std::endl;

	if (!tBackHomeButton.loadFromFile("./data/images/back and home.png"))
		std::cout << "��ƨŶ��back and home.png�Ҳ�������" << std::endl;

	if (!tBlackBlocWord.loadFromFile("./data/images/Black.png"))
		std::cout << "��ƨŶ��Black.png�Ҳ�������" << std::endl;

	if (!tRedBlocWord.loadFromFile("./data/images/Red.png"))
		std::cout << "��ƨŶ��Red.png�Ҳ�������" << std::endl;

	if (!tUnknownBlocWord.loadFromFile("./data/images/Unknown.png"))
		std::cout << "��ƨŶ��Unknown.png�Ҳ�������" << std::endl;

	if (!tPieceTakerWord.loadFromFile("./data/images/piece taker.png"))
		std::cout << "��ƨŶ��piece taker.png�Ҳ�������" << std::endl;

	if (!tLastDeathWord.loadFromFile("./data/images/last death.png"))
		std::cout << "��ƨŶ��last death.png�Ҳ�������" << std::endl;

	if (!tWinnerWord.loadFromFile("./data/images/winner.png"))
		std::cout << "��ƨŶ��winner.png�Ҳ�������" << std::endl;

	if (!tAcceptRetractWord.loadFromFile("./data/images/whether to accept retract.png"))
		std::cout << "��ƨŶ��whether to accept retract.png�Ҳ�������" << std::endl;

	if (!tAcceptTieWord.loadFromFile("./data/images/whether to accept tie.png"))
		std::cout << "��ƨŶ��whether to accept tie.png�Ҳ�������" << std::endl;

	if (!tToSurrenderWord.loadFromFile("./data/images/whether to surrender.png"))
		std::cout << "��ƨŶ��whether to surrender.png�Ҳ�������" << std::endl;

	if (!tBackHomeWord.loadFromFile("./data/images/whether to back home.png"))
		std::cout << "��ƨŶ��whether to back home.png�Ҳ�������" << std::endl;

	if (!tCoverFileWord.loadFromFile("./data/images/whether to cover file.png"))
		std::cout << "��ƨŶ��whether to cover file.png�Ҳ�������" << std::endl;

	if (!tBGMWord.loadFromFile("./data/images/BGM.png"))
		std::cout << "��ƨŶ��BGM.png�Ҳ�������" << std::endl;

	if (!tSEWord.loadFromFile("./data/images/SE.png"))
		std::cout << "��ƨŶ��SE.png�Ҳ�������" << std::endl;

	if (!tSaveWord.loadFromFile("./data/images/save.png"))
		std::cout << "��ƨŶ��save.png�Ҳ�������" << std::endl;

	if (!tLoadWord.loadFromFile("./data/images/load.png"))
		std::cout << "��ƨŶ��load.png�Ҳ�������" << std::endl;

	if (!StartPageBKMusic.openFromFile("./data/Audios/StartPageBackgroudMusic.ogg"))
		std::cout << "��ƨŶ��StartPageBackgroudMusic.ogg�Ҳ�������" << std::endl;

	if (!GamePageBKMusic.openFromFile("./data/Audios/GamePageBackgroundMusic.ogg"))
		std::cout << "��ƨŶ��GamePageBackgroundMusic.ogg�Ҳ�������" << std::endl;

	if (!sbButton.loadFromFile("./data/Audios/ButtonClick.wav"))
		std::cout << "��ƨŶ��ButtonClick.wav�Ҳ�������" << std::endl;

	if (!sbPiece.loadFromFile("./data/Audios/PieceChosen.ogg"))
		std::cout << "��ƨŶ��PieceChosen.ogg�Ҳ�������" << std::endl;

	if (!chess.tUnturnedPiece.loadFromFile("./data/images/pieceback.png"))
		std::cout << "��ƨŶ��pieceback.png�Ҳ�������" << std::endl;

	if (!chess.tPiece.loadFromFile("./data/images/allpiece.png"))
		std::cout << "��ƨŶ��allpiece.png�Ҳ�������" << std::endl;

	if (!chess.tMarqueeGrey.loadFromFile("./data/images/Marquee grey.png"))
		std::cout << "��ƨŶ��Marquee grey.png�Ҳ�������" << std::endl;

	if (!chess.tMarqueeRed.loadFromFile("./data/images/Marquee red.png"))
		std::cout << "��ƨŶ��Marquee red.png�Ҳ�������" << std::endl;

	if (!font.loadFromFile("./data/fonts/STXINGKA.TTF"))
		std::cout << "��ƨŶ��STXINGKA.TTF�Ҳ�������" << std::endl;
	
	spBackground.setTexture(tBackground);
	spStartPage.setTexture(tStartPage);
	spDeathPieceMarquee.setTexture(tDeathPieceMarquee);
	spPopWindow.setTexture(tPopWindow);
	spVolumeStripeSlider.setTexture(tVolumeStripeSlider);
	spRule.setTexture(tRule);
	spBigPopWindow.setTexture(tBigPopWindow);
	spRectangle.setTexture(tRectangle);

	spButtons.setTexture(tButtons);
	spTurnOffButton.setTexture(tTurnOffButton);
	spSettingPageButton.setTexture(tSettingPageButton);
	spVolumeChangeButton.setTexture(tVolumeChangeButton);
	spVolumeTurnButton.setTexture(tVolumeTurnButton);
	spBackHomeButton.setTexture(tBackHomeButton);

	spPieceTakerWord.setTexture(tPieceTakerWord);
	spLastDeathWord.setTexture(tLastDeathWord);
	spWinnerWord.setTexture(tWinnerWord);
	spBackHomeWord.setTexture(tBackHomeWord);
	spCoverFileWord.setTexture(tCoverFileWord);
	spBGMWord.setTexture(tBGMWord);
	spSEWord.setTexture(tSEWord);
	spSaveWord.setTexture(tSaveWord);
	spLoadWord.setTexture(tLoadWord);

	soundButton.setBuffer(sbButton);
	soundPiece.setBuffer(sbPiece);
	soundWrongPiece.setBuffer(sbWrongPiece);

	chess.spMarqueeGrey.setTexture(chess.tMarqueeGrey);
	chess.spMarqueeRed.setTexture(chess.tMarqueeRed);

	chess.spMarqueeGrey.setOrigin(PIECE_EDGE_LENTH / 2, PIECE_EDGE_LENTH / 2);
	chess.spMarqueeRed.setOrigin(PIECE_EDGE_LENTH / 2, PIECE_EDGE_LENTH / 2);

	text.setFont(font);
}

void Game::drawSingleButton(Sprite* spButton, IntRect* ButtonRect, int grid_x, int grid_y, int button_position_x, int button_position_y, int button_width, int button_height)
{
	(*spButton).setTextureRect(IntRect(grid_x * button_width, grid_y * button_height, button_width, button_height));
	(*spButton).setPosition(button_position_x, button_position_y);
	(*ButtonRect).left = button_position_x;
	(*ButtonRect).top = button_position_y;
	(*ButtonRect).width = button_width;
	(*ButtonRect).height = button_height;
	window.draw(*spButton);
}

void Game::drawButtons(int GS)
{
	switch (GS)
	{
	case START_PAGE:
		//ButtonRectLocalStart
		drawSingleButton(&spButtons, &ButtonRectLocalStart, 2, 0, BUTTON_LOCAL_START_X, BUTTON_LOCAL_START_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		//ButtonRectOnlineStart
		drawSingleButton(&spButtons, &ButtonRectOnlineStart, 3, 0, BUTTON_ONLINE_START_X, BUTTON_ONLINE_START_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		//ButtonRectExit
		drawSingleButton(&spButtons, &ButtonRectExit, 1, 0, BUTTON_STARTPAGE_EXIT_X, BUTTON_STARTPAGE_EXIT_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		//ButtonRectSetting
		drawSingleButton(&spButtons, &ButtonRectSetting, 0, 2, BUTTON_STARTPAGE_SETTING_X, BUTTON_STARTPAGE_SETTING_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		break;

	case GAME_PAGE:
		spButtons.setScale(BUTTON_GAMEPAGE_SCALE, BUTTON_GAMEPAGE_SCALE);
		//ButtonRectRegret
		drawSingleButton(&spButtons, &ButtonRectRegret, 0, 1, BUTTON_REGRET_X, BUTTON_REGRET_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		//ButtonRectTie
		drawSingleButton(&spButtons, &ButtonRectTie, 0, 3, BUTTON_TIE_X, BUTTON_TIE_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		//ButtonRectSurrender
		drawSingleButton(&spButtons, &ButtonRectSurrender, 1, 1, BUTTON_SURRENDER_X, BUTTON_SURRENDER_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		spButtons.setScale(1,1);

		//ButtonRectSetting
		drawSingleButton(&spButtons, &ButtonRectSetting, 0, 2, BUTTON_GAMEPAGE_SETTING_X, BUTTON_GAMEPAGE_SETTING_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		break;

	case GAME_PAUSED_PAGE:
		//ButtonRectTurnOff
		drawSingleButton(&spTurnOffButton, &ButtonRectTurnOff, 0, 0, BUTTON_TURN_OFF_X + POP_WINDOW_X, BUTTON_TURN_OFF_Y + POP_WINDOW_Y, BUTTON_TURN_OFF_EDGE_LENTH, BUTTON_TURN_OFF_EDGE_LENTH);

		switch (lastClickState)
		{
		case REGRET_BUTTON:
		case TIE_BUTTON:
		case SURRENDER_BUTTON:
		case HOME_BUTTON:
			//ButtonRectYes
			drawSingleButton(&spButtons, &ButtonRectYes, 2, 2, BUTTON_YES_X + POP_WINDOW_X, BUTTON_YES_Y + POP_WINDOW_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
			//ButtonRectNo
			drawSingleButton(&spButtons, &ButtonRectNo, 3, 2, BUTTON_NO_X + POP_WINDOW_X, BUTTON_NO_Y + POP_WINDOW_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
			break;

		case SETTING_BUTTON_FROM_START_PAGE:
			switch (settingPage)
			{
			case SETTING_PAGE_LOGIC:
				//ButtonRectSettingPageLogic
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageLogic, 0, 0, BUTTON_SETTING_PAGE_LOGIC_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);
				//ButtonRectSettingPageRule
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageRule, 1, 1, BUTTON_SETTING_PAGE_RULE_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);

				//ButtonRectBGMVolumePlus
				drawSingleButton(&spVolumeChangeButton, &ButtonRectBGMVolumePlus, 1, 0, BUTTON_BGM_VOLUME_PLUS_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_PLUS_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectBGMVolumeSubstruct
				drawSingleButton(&spVolumeChangeButton, &ButtonRectBGMVolumeSubstruct, 0, 0, BUTTON_BGM_VOLUME_SUBSTRUCT_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_SUBSTRUCT_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectBGMVolumeTurn
				if (isMusicOn)
					drawSingleButton(&spVolumeTurnButton, &ButtonRectBGMVolumeTurn, 1, 0, BUTTON_BGM_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);
				else
					drawSingleButton(&spVolumeTurnButton, &ButtonRectBGMVolumeTurn, 0, 0, BUTTON_BGM_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);
				
				//ButtonRectSEVolumePlus
				drawSingleButton(&spVolumeChangeButton, &ButtonRectSEVolumePlus, 1, 0, BUTTON_SE_VOLUME_PLUS_X + POP_WINDOW_X, BUTTON_SE_VOLUME_PLUS_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectSEVolumeSubstruct
				drawSingleButton(&spVolumeChangeButton, &ButtonRectSEVolumeSubstruct, 0, 0, BUTTON_SE_VOLUME_SUBSTRUCT_X + POP_WINDOW_X, BUTTON_SE_VOLUME_SUBSTRUCT_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectSEVolumeTurn
				if (isSoundOn)
					drawSingleButton(&spVolumeTurnButton, &ButtonRectSEVolumeTurn, 1, 0, BUTTON_SE_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_SE_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);
				else
					drawSingleButton(&spVolumeTurnButton, &ButtonRectSEVolumeTurn, 0, 0, BUTTON_SE_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_SE_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);

				//ButtonRectBGMStripe
				spVolumeStripeSlider.setTextureRect(IntRect(0, 0, BUTTON_VOLUME_STRIPE_WIDTH, BUTTON_VOLUME_STRIPE_HEIGHT));
				spVolumeStripeSlider.setOrigin(0, 0);
				spVolumeStripeSlider.setPosition(BUTTON_BGM_STRIPE_X + POP_WINDOW_X, BUTTON_BGM_STRIPE_Y + POP_WINDOW_Y);
				ButtonRectBGMStripe.left = BUTTON_BGM_STRIPE_X + POP_WINDOW_X;
				ButtonRectBGMStripe.top = BUTTON_BGM_STRIPE_Y + POP_WINDOW_Y;
				ButtonRectBGMStripe.width = BUTTON_VOLUME_STRIPE_WIDTH;
				ButtonRectBGMStripe.height = BUTTON_VOLUME_STRIPE_HEIGHT;
				window.draw(spVolumeStripeSlider);
				//ButtonRectBGMSlider
				spVolumeStripeSlider.setTextureRect(IntRect(0, BUTTON_VOLUME_STRIPE_HEIGHT, BUTTON_VOLUME_SLIDER_WIDTH, BUTTON_VOLUME_SLIDER_HEIGHT));
				spVolumeStripeSlider.setOrigin(BUTTON_VOLUME_SLIDER_WIDTH / 2, 0);
				spVolumeStripeSlider.setPosition((BUTTON_VOLUME_STRIPE_WIDTH * musicVolume / 100) + BUTTON_BGM_STRIPE_X + POP_WINDOW_X, BUTTON_BGM_SLIDER_Y + POP_WINDOW_Y);
				ButtonRectBGMSlider.left = (BUTTON_VOLUME_STRIPE_WIDTH * musicVolume / 100) + BUTTON_BGM_STRIPE_X + POP_WINDOW_X;
				ButtonRectBGMSlider.top = BUTTON_BGM_SLIDER_Y + POP_WINDOW_Y;
				ButtonRectBGMSlider.width = BUTTON_VOLUME_SLIDER_WIDTH;
				ButtonRectBGMSlider.height = BUTTON_VOLUME_SLIDER_HEIGHT;
				window.draw(spVolumeStripeSlider);

				//ButtonRectSEStripe
				spVolumeStripeSlider.setTextureRect(IntRect(0, 0, BUTTON_VOLUME_STRIPE_WIDTH, BUTTON_VOLUME_STRIPE_HEIGHT));
				spVolumeStripeSlider.setOrigin(0, 0);
				spVolumeStripeSlider.setPosition(BUTTON_SE_STRIPE_X + POP_WINDOW_X, BUTTON_SE_STRIPE_Y + POP_WINDOW_Y);
				ButtonRectSEStripe.left = BUTTON_SE_STRIPE_X + POP_WINDOW_X;
				ButtonRectSEStripe.top = BUTTON_SE_STRIPE_Y + POP_WINDOW_Y;
				ButtonRectSEStripe.width = BUTTON_VOLUME_STRIPE_WIDTH;
				ButtonRectSEStripe.height = BUTTON_VOLUME_STRIPE_HEIGHT;
				window.draw(spVolumeStripeSlider);
				//ButtonRectSESlider
				spVolumeStripeSlider.setTextureRect(IntRect(0, BUTTON_VOLUME_STRIPE_HEIGHT, BUTTON_VOLUME_SLIDER_WIDTH, BUTTON_VOLUME_SLIDER_HEIGHT));
				spVolumeStripeSlider.setOrigin(BUTTON_VOLUME_SLIDER_WIDTH / 2, 0);
				spVolumeStripeSlider.setPosition((BUTTON_VOLUME_STRIPE_WIDTH * soundVolume / 100) + BUTTON_SE_STRIPE_X + POP_WINDOW_X, BUTTON_SE_SLIDER_Y + POP_WINDOW_Y);
				ButtonRectSESlider.left = (BUTTON_VOLUME_STRIPE_WIDTH * soundVolume / 100) + BUTTON_SE_STRIPE_X + POP_WINDOW_X;
				ButtonRectSESlider.top = BUTTON_SE_SLIDER_Y + POP_WINDOW_Y;
				ButtonRectSESlider.width = BUTTON_VOLUME_SLIDER_WIDTH;
				ButtonRectSESlider.height = BUTTON_VOLUME_SLIDER_HEIGHT;
				window.draw(spVolumeStripeSlider);

				break;

			case SETTING_PAGE_RULE:
				//ButtonRectSettingPageLogic
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageLogic, 0, 1, BUTTON_SETTING_PAGE_LOGIC_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);
				//ButtonRectSettingPageRule
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageRule, 1, 0, BUTTON_SETTING_PAGE_RULE_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);
				break;
			}
			break;
		case SETTING_BUTTON_FROM_GAME_PAGE:
			switch (settingPage)
			{
			case SETTING_PAGE_LOGIC:
				//ButtonRectSettingPageLogic
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageLogic, 0, 0, BUTTON_SETTING_PAGE_LOGIC_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);
				//ButtonRectSettingPageRule
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageRule, 1, 1, BUTTON_SETTING_PAGE_RULE_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);

				//ButtonRectSave
				drawSingleButton(&spButtons, &ButtonRectSave, 2, 1, BUTTON_SAVE_X + POP_WINDOW_X, BUTTON_SAVE_Y + POP_WINDOW_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
				//ButtonRectLoad
				drawSingleButton(&spButtons, &ButtonRectLoad, 3, 1, BUTTON_LOAD_X + POP_WINDOW_X, BUTTON_LOAD_Y + POP_WINDOW_Y, BUTTON_WIDTH, BUTTON_HEIGHT);

				//ButtonRectHome
				drawSingleButton(&spBackHomeButton, &ButtonRectHome, 1, 0, BUTTON_HOME_X + POP_WINDOW_X, BUTTON_HOME_Y + POP_WINDOW_Y, BUTTON_HOME_BACK_EDGE_LENTH, BUTTON_HOME_BACK_EDGE_LENTH);

				//ButtonRectBGMVolumePlus
				drawSingleButton(&spVolumeChangeButton, &ButtonRectBGMVolumePlus, 1, 0, BUTTON_BGM_VOLUME_PLUS_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_PLUS_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectBGMVolumeSubstruct
				drawSingleButton(&spVolumeChangeButton, &ButtonRectBGMVolumeSubstruct, 0, 0, BUTTON_BGM_VOLUME_SUBSTRUCT_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_SUBSTRUCT_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectBGMVolumeTurn
				if (isMusicOn)
					drawSingleButton(&spVolumeTurnButton, &ButtonRectBGMVolumeTurn, 1, 0, BUTTON_BGM_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);
				else
					drawSingleButton(&spVolumeTurnButton, &ButtonRectBGMVolumeTurn, 0, 0, BUTTON_BGM_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_BGM_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);

				//ButtonRectSEVolumePlus
				drawSingleButton(&spVolumeChangeButton, &ButtonRectSEVolumePlus, 1, 0, BUTTON_SE_VOLUME_PLUS_X + POP_WINDOW_X, BUTTON_SE_VOLUME_PLUS_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectSEVolumeSubstruct
				drawSingleButton(&spVolumeChangeButton, &ButtonRectSEVolumeSubstruct, 0, 0, BUTTON_SE_VOLUME_SUBSTRUCT_X + POP_WINDOW_X, BUTTON_SE_VOLUME_SUBSTRUCT_Y + POP_WINDOW_Y, BUTTON_VOLUME_CHANGE_EDGE_LENTH, BUTTON_VOLUME_CHANGE_EDGE_LENTH);
				//ButtonRectSEVolumeTurn
				if (isSoundOn)
					drawSingleButton(&spVolumeTurnButton, &ButtonRectSEVolumeTurn, 1, 0, BUTTON_SE_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_SE_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);
				else
					drawSingleButton(&spVolumeTurnButton, &ButtonRectSEVolumeTurn, 0, 0, BUTTON_SE_VOLUME_TURN_X + POP_WINDOW_X, BUTTON_SE_VOLUME_TURN_Y + POP_WINDOW_Y, BUTTON_VOLUME_TURN_EDGE_LENTH, BUTTON_VOLUME_TURN_EDGE_LENTH);

				//ButtonRectBGMStripe
				spVolumeStripeSlider.setTextureRect(IntRect(0, 0, BUTTON_VOLUME_STRIPE_WIDTH, BUTTON_VOLUME_STRIPE_HEIGHT));
				spVolumeStripeSlider.setOrigin(0, 0);
				spVolumeStripeSlider.setPosition(BUTTON_BGM_STRIPE_X + POP_WINDOW_X, BUTTON_BGM_STRIPE_Y + POP_WINDOW_Y);
				ButtonRectBGMStripe.left = BUTTON_BGM_STRIPE_X + POP_WINDOW_X;
				ButtonRectBGMStripe.top = BUTTON_BGM_STRIPE_Y + POP_WINDOW_Y;
				ButtonRectBGMStripe.width = BUTTON_VOLUME_STRIPE_WIDTH;
				ButtonRectBGMStripe.height = BUTTON_VOLUME_STRIPE_HEIGHT;
				window.draw(spVolumeStripeSlider);
				//ButtonRectBGMSlider
				spVolumeStripeSlider.setTextureRect(IntRect(0, BUTTON_VOLUME_STRIPE_HEIGHT, BUTTON_VOLUME_SLIDER_WIDTH, BUTTON_VOLUME_SLIDER_HEIGHT));
				spVolumeStripeSlider.setOrigin(BUTTON_VOLUME_SLIDER_WIDTH / 2, 0);
				spVolumeStripeSlider.setPosition((BUTTON_VOLUME_STRIPE_WIDTH* musicVolume / 100) + BUTTON_BGM_STRIPE_X + POP_WINDOW_X, BUTTON_BGM_SLIDER_Y + POP_WINDOW_Y);
				ButtonRectBGMSlider.left = (BUTTON_VOLUME_STRIPE_WIDTH * musicVolume / 100) + BUTTON_BGM_STRIPE_X + POP_WINDOW_X;
				ButtonRectBGMSlider.top = BUTTON_BGM_SLIDER_Y + POP_WINDOW_Y;
				ButtonRectBGMSlider.width = BUTTON_VOLUME_SLIDER_WIDTH;
				ButtonRectBGMSlider.height = BUTTON_VOLUME_SLIDER_HEIGHT;
				window.draw(spVolumeStripeSlider);

				//ButtonRectSEStripe
				spVolumeStripeSlider.setTextureRect(IntRect(0, 0, BUTTON_VOLUME_STRIPE_WIDTH, BUTTON_VOLUME_STRIPE_HEIGHT));
				spVolumeStripeSlider.setOrigin(0, 0);
				spVolumeStripeSlider.setPosition(BUTTON_SE_STRIPE_X + POP_WINDOW_X, BUTTON_SE_STRIPE_Y + POP_WINDOW_Y);
				ButtonRectSEStripe.left = BUTTON_SE_STRIPE_X + POP_WINDOW_X;
				ButtonRectSEStripe.top = BUTTON_SE_STRIPE_Y + POP_WINDOW_Y;
				ButtonRectSEStripe.width = BUTTON_VOLUME_STRIPE_WIDTH;
				ButtonRectSEStripe.height = BUTTON_VOLUME_STRIPE_HEIGHT;
				window.draw(spVolumeStripeSlider);
				//ButtonRectSESlider
				spVolumeStripeSlider.setTextureRect(IntRect(0, BUTTON_VOLUME_STRIPE_HEIGHT, BUTTON_VOLUME_SLIDER_WIDTH, BUTTON_VOLUME_SLIDER_HEIGHT));
				spVolumeStripeSlider.setOrigin(BUTTON_VOLUME_SLIDER_WIDTH / 2, 0);
				spVolumeStripeSlider.setPosition((BUTTON_VOLUME_STRIPE_WIDTH* soundVolume / 100) + BUTTON_SE_STRIPE_X + POP_WINDOW_X, BUTTON_SE_SLIDER_Y + POP_WINDOW_Y);
				ButtonRectSESlider.left = (BUTTON_VOLUME_STRIPE_WIDTH * soundVolume / 100) + BUTTON_SE_STRIPE_X + POP_WINDOW_X;
				ButtonRectSESlider.top = BUTTON_SE_SLIDER_Y + POP_WINDOW_Y;
				ButtonRectSESlider.width = BUTTON_VOLUME_SLIDER_WIDTH;
				ButtonRectSESlider.height = BUTTON_VOLUME_SLIDER_HEIGHT;
				window.draw(spVolumeStripeSlider);

				break;

			case SETTING_PAGE_RULE:
				//ButtonRectSettingPageLogic
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageLogic, 0, 1, BUTTON_SETTING_PAGE_LOGIC_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);
				//ButtonRectSettingPageRule
				drawSingleButton(&spSettingPageButton, &ButtonRectSettingPageRule, 1, 0, BUTTON_SETTING_PAGE_RULE_X + POP_WINDOW_X, BUTTON_SETTING_PAGE_Y + POP_WINDOW_Y, SETTING_PAGE_BUTTON_WIDTH, SETTING_PAGE_BUTTON_HEIGHT);
				break;
			}
			break;
		}
		break;
	case SAVE_PAGE:
	case LOAD_PAGE:
		//ButtonRectBack
		drawSingleButton(&spBackHomeButton, &ButtonRectBack, 0, 0, BUTTON_BACK_X + BIG_POP_WINDOW_X, BUTTON_BACK_Y + BIG_POP_WINDOW_Y, BUTTON_HOME_BACK_EDGE_LENTH, BUTTON_HOME_BACK_EDGE_LENTH);
		//ButtonRectSL1-6
		drawSingleButton(&spRectangle, &ButtonRectSLOne, 0, 0, SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y, RECTANGLE_WIDTH, RECTANGLE_HEIGHT);
		drawSingleButton(&spRectangle, &ButtonRectSLTwo, 0, 0, SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y, RECTANGLE_WIDTH, RECTANGLE_HEIGHT);
		drawSingleButton(&spRectangle, &ButtonRectSLThree, 0, 0, SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y, RECTANGLE_WIDTH, RECTANGLE_HEIGHT);
		drawSingleButton(&spRectangle, &ButtonRectSLFour, 0, 0, SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y, RECTANGLE_WIDTH, RECTANGLE_HEIGHT);
		drawSingleButton(&spRectangle, &ButtonRectSLFive, 0, 0, SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y, RECTANGLE_WIDTH, RECTANGLE_HEIGHT);
		drawSingleButton(&spRectangle, &ButtonRectSLSix, 0, 0, SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y, RECTANGLE_WIDTH, RECTANGLE_HEIGHT);
		break;

	case GAME_OVER_PAGE:
		//ButtonRectRestart
		drawSingleButton(&spButtons, &ButtonRectRestart, 4, 0, BUTTON_RESTART_X + POP_WINDOW_X, BUTTON_RESTART_Y + POP_WINDOW_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		//ButtonRectExit
		drawSingleButton(&spButtons, &ButtonRectExit, 1, 0, BUTTON_GAMEOVER_EXIT_X + POP_WINDOW_X, BUTTON_GAMEOVER_EXIT_Y + POP_WINDOW_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
		break;

	default:
		break;
	}
}

void Game::drawPiece()
{
	for (int i = 0; i < 32; i++)
	{
		if (!chess.piece[i].isDeath)
		{
			chess.piece[i].spPiece.setOrigin(PIECE_EDGE_LENTH / 2, PIECE_EDGE_LENTH / 2);
			chess.piece[i].spPiece.setPosition(ORIGIN_GRID_CENTER_POINT_X + chess.piece[i].piecePosition.x * GRID_SIZE, ORIGIN_GRID_CENTER_POINT_Y + chess.piece[i].piecePosition.y * GRID_SIZE);
			window.draw(chess.piece[i].spPiece);
		}
	}
}

void Game::drawSaveWord(std::string s, int saveWordPosX, int saveWordPosY, int saveTimePosX, int saveTimePosY)
{
	std::stringstream ss;

	text.setCharacterSize(48);
	text.setFillColor(Color::Color(0, 0, 0, 255));
	if (s == "save 1.txt")
		text.setString(L"�浵һ");
	else if (s == "save 2.txt")
		text.setString(L"�浵��");
	else if (s == "save 3.txt")
		text.setString(L"�浵��");
	else if (s == "save 4.txt")
		text.setString(L"�浵��");
	else if (s == "save 5.txt")
		text.setString(L"�浵��");
	else if (s == "save 6.txt")
		text.setString(L"�浵��");
	text.setOrigin(0, 0);
	text.setPosition(saveWordPosX, saveWordPosY);
	window.draw(text);

	in.open(s);
	if (!in)
	{
		text.setCharacterSize(36);
		text.setString("No Data");
		fRect = text.getLocalBounds();
		text.setOrigin(fRect.width, fRect.height);
		text.setPosition(saveTimePosX, saveTimePosY);
	}
	else
	{
		text.setCharacterSize(36);
		in >> sysTime.wYear >> sysTime.wMonth >> sysTime.wDay;
		in >> sysTime.wHour >> sysTime.wMinute >> sysTime.wSecond;

		ss.str("");
		ss << sysTime.wYear << " / " << sysTime.wMonth << " / " << sysTime.wDay << "  " << sysTime.wHour << ":" << sysTime.wMinute << ":" << sysTime.wSecond;
		text.setString(ss.str());
		fRect = text.getLocalBounds();
		text.setOrigin(fRect.width, fRect.height);
		text.setPosition(saveTimePosX, saveTimePosY);
	}
	in.close();
	window.draw(text);
}

void Game::gamePageDraw()
{
	spBackground.setPosition(0, 0);
	window.draw(spBackground);

	if (chess.isClicked)
	{
		chess.spMarqueeGrey.setPosition(ORIGIN_GRID_CENTER_POINT_X + chess.chosenPos.x * GRID_SIZE, ORIGIN_GRID_CENTER_POINT_Y + chess.chosenPos.y * GRID_SIZE);
		window.draw(chess.spMarqueeGrey);
	}

	if (!chess.firstOpen && !chess.secondClick)
	{
		chess.spMarqueeRed.setPosition(ORIGIN_GRID_CENTER_POINT_X + chess.chosenPos2.x * GRID_SIZE, ORIGIN_GRID_CENTER_POINT_Y + chess.chosenPos2.y * GRID_SIZE);
		window.draw(chess.spMarqueeRed);
	}

	drawPiece();

	spPieceTakerWord.setPosition(PIECE_TAKER_WORD_X, PIECE_TAKER_WORD_Y);
	window.draw(spPieceTakerWord);

	if (chess.bloc == c_RED && !chess.firstOpen)
		spBlocWord.setTexture(tRedBlocWord);
	else if (chess.bloc == c_BLACK && !chess.firstOpen)
		spBlocWord.setTexture(tBlackBlocWord);
	else if (chess.firstOpen)
		spBlocWord.setTexture(tUnknownBlocWord);

	spBlocWord.setPosition(BLOC_WORD_X, BLOC_WORD_Y);
	window.draw(spBlocWord);

	spLastDeathWord.setPosition(LAST_DEATH_WORD_X, LAST_DEATH_WORD_Y);
	window.draw(spLastDeathWord);

	spDeathPieceMarquee.setPosition(DEATH_PIECE_MARQUEE_X, DEATH_PIECE_MARQUEE_Y);
	window.draw(spDeathPieceMarquee);

	switch (chess.lastDeadPieceNum)
	{
	case 0:
		break;
	case 1:
		chess.lastDeadPiece[0].spPiece.setPosition(DEATH_PIECE_1_X, DEATH_PIECE_Y);
		chess.lastDeadPiece[0].pieceOpen(&chess.tPiece);
		window.draw(chess.lastDeadPiece[0].spPiece);
		break;
	case 2:
		chess.lastDeadPiece[0].spPiece.setPosition(DEATH_PIECE_2_FIRST_X, DEATH_PIECE_Y);
		chess.lastDeadPiece[1].spPiece.setPosition(DEATH_PIECE_2_SECOND_X, DEATH_PIECE_Y);
		chess.lastDeadPiece[0].pieceOpen(&chess.tPiece);
		chess.lastDeadPiece[1].pieceOpen(&chess.tPiece);
		window.draw(chess.lastDeadPiece[0].spPiece);
		window.draw(chess.lastDeadPiece[1].spPiece);
		break;
	}

	drawButtons(GAME_PAGE);
}

void Game::gameInit()
{
	gameState = START_PAGE;
	gameOver = false;
	gameQuit = false;
	yesClicked = false;
	noClicked = false;
	BGMSliderClicked = false;
	SESliderClicked = false;
	clickedPos.x = -1;
	clickedPos.y = -1;
	originPos.x = -1;
	originPos.y = -1;
	lastClickState = PIECE;
	settingPage = SETTING_PAGE_LOGIC;
	ruleAdjustment = 0;

	isMusicOn = true;
	isSoundOn = true;
	musicVolume = 50;
	soundVolume = 50;

	loadMediaData();

	StartPageBKMusic.setVolume(musicVolume);
	StartPageBKMusic.play();
	StartPageBKMusic.setLoop(true);

	GamePageBKMusic.setVolume(musicVolume);

}

void Game::gameInput()
{
	sf::Event event;
	while (window.pollEvent((event)))
	{
		if (event.type == sf::Event::Closed)
		{
			window.close();
			gameQuit = true;
		}

		if (event.type == sf::Event::EventType::KeyReleased && event.key.code == sf::Keyboard::Escape)
		{
			window.close();
			gameQuit = true;
		}

		switch (gameState)
		{
		case START_PAGE:
			switch (event.type)
			{
			case Event::MouseButtonPressed:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectLocalStart.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectExit.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSetting.contains(event.mouseButton.x, event.mouseButton.y))
					{
						clickedPos.x = event.mouseButton.x;
						clickedPos.y = event.mouseButton.y;
					}
				}
				break;
			case Event::MouseButtonReleased:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectLocalStart.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						gameState = GAME_PAGE;
						chess.initPiece();
						formerChess = chess;

						if (isMusicOn)
						{
							StartPageBKMusic.stop();
							GamePageBKMusic.play();
							GamePageBKMusic.setLoop(true);
						}

						clickedPos = originPos;
					}

					if (ButtonRectExit.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						window.close();
						gameQuit = true;

						clickedPos = originPos;
					}

					if (ButtonRectSetting.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						lastClickState = SETTING_BUTTON_FROM_START_PAGE;
						gameState = GAME_PAUSED_PAGE;

						clickedPos = originPos;
					}
				}
				break;
			}
			break;
		case GAME_PAGE:
			switch (event.type)
			{
			case Event::MouseButtonPressed:
				if (event.mouseButton.button == Mouse::Left)
				{
					if ((ButtonRectRegret.contains(event.mouseButton.x, event.mouseButton.y) && !chess.firstOpen) ||
						ButtonRectTie.contains(event.mouseButton.x, event.mouseButton.y) ||
						(ButtonRectSurrender.contains(event.mouseButton.x, event.mouseButton.y) && !chess.firstOpen) ||
						ButtonRectSetting.contains(event.mouseButton.x, event.mouseButton.y))
					{
						clickedPos.x = event.mouseButton.x;
						clickedPos.y = event.mouseButton.y;
					}

					if (!chess.firstClick)
					{
						if ((event.mouseButton.x - ORIGIN_GRID_LEFT_UP_POINT_X) / GRID_SIZE >= 0 && (event.mouseButton.x - ORIGIN_GRID_LEFT_UP_POINT_X) / GRID_SIZE < 8 &&
							(event.mouseButton.y - ORIGIN_GRID_LEFT_UP_POINT_Y) / GRID_SIZE >= 0 && (event.mouseButton.y - ORIGIN_GRID_LEFT_UP_POINT_Y) / GRID_SIZE < 4)
						{
							if (isSoundOn)
								soundPiece.play();

							chess.stepBeforeChosenPos = chess.chosenPos;

							chess.chosenPos.x = (event.mouseButton.x - ORIGIN_GRID_LEFT_UP_POINT_X) / GRID_SIZE;
							chess.chosenPos.y = (event.mouseButton.y - ORIGIN_GRID_LEFT_UP_POINT_Y) / GRID_SIZE;
							chess.firstClick = true;
							lastClickState = PIECE;
						}
					}
					else if (!chess.secondClick)
					{
						if ((event.mouseButton.x - ORIGIN_GRID_LEFT_UP_POINT_X) / GRID_SIZE >= 0 && (event.mouseButton.x - ORIGIN_GRID_LEFT_UP_POINT_X) / GRID_SIZE < 8 &&
							(event.mouseButton.y - ORIGIN_GRID_LEFT_UP_POINT_Y) / GRID_SIZE >= 0 && (event.mouseButton.y - ORIGIN_GRID_LEFT_UP_POINT_Y) / GRID_SIZE < 4)
						{
							if (isSoundOn)
								soundPiece.play();

							chess.chosenPos2.x = (event.mouseButton.x - ORIGIN_GRID_LEFT_UP_POINT_X) / GRID_SIZE;
							chess.chosenPos2.y = (event.mouseButton.y - ORIGIN_GRID_LEFT_UP_POINT_Y) / GRID_SIZE;
							chess.secondClick = true;
							lastClickState = PIECE;
						}
					}
				}
				break;
			case Event::MouseButtonReleased:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectRegret.contains(clickedPos.x, clickedPos.y) && !chess.firstOpen)
					{
						if (isSoundOn)
							soundButton.play();

						lastClickState = REGRET_BUTTON;
					}

					if (ButtonRectTie.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						lastClickState = TIE_BUTTON;
					}

					if (ButtonRectSurrender.contains(clickedPos.x, clickedPos.y) && !chess.firstOpen)
					{
						if (isSoundOn)
							soundButton.play();

						lastClickState = SURRENDER_BUTTON;
					}

					if (ButtonRectSetting.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						lastClickState = SETTING_BUTTON_FROM_GAME_PAGE;
					}
					clickedPos = originPos;
				}
				break;
			case Event::KeyReleased:
				//���ţ�ȫ������
				if (event.key.code == Keyboard::O)
				{
					for (int i = 0; i < 32; i++)
					{
						chess.piece[i].pieceOpen(&chess.tPiece);
					}
				}
				break;
			}
			break;
		case GAME_PAUSED_PAGE:
			switch (event.type)
			{
			case Event::EventType::MouseButtonPressed:
				if (event.mouseButton.button == Mouse::Left)
				{
					switch (lastClickState)
					{
					case SETTING_BUTTON_FROM_START_PAGE:
						switch (settingPage)
						{
						case SETTING_PAGE_LOGIC:
							if (ButtonRectTurnOff.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectBGMVolumeSubstruct.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectBGMVolumePlus.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectBGMVolumeTurn.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSEVolumeSubstruct.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSEVolumePlus.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSEVolumeTurn.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageLogic.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageRule.contains(event.mouseButton.x, event.mouseButton.y))
							{
								clickedPos.x = event.mouseButton.x;
								clickedPos.y = event.mouseButton.y;
							}
							else if (ButtonRectBGMSlider.contains(event.mouseButton.x, event.mouseButton.y))
								BGMSliderClicked = true;
							else if (ButtonRectSESlider.contains(event.mouseButton.x, event.mouseButton.y))
								SESliderClicked = true;
							else if (ButtonRectBGMStripe.contains(event.mouseButton.x, event.mouseButton.y))
							{
								musicVolume = (event.mouseButton.x - POP_WINDOW_X - BUTTON_BGM_STRIPE_X) * (float)100 / BUTTON_VOLUME_STRIPE_WIDTH;
								BGMSliderClicked = true;
							}
							else if (ButtonRectSEStripe.contains(event.mouseButton.x, event.mouseButton.y))
							{
								soundVolume = (event.mouseButton.x - POP_WINDOW_X - BUTTON_SE_STRIPE_X) * (float)100 / BUTTON_VOLUME_STRIPE_WIDTH;
								SESliderClicked = true;
							}
							break;
						case SETTING_PAGE_RULE:
							if (ButtonRectTurnOff.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageLogic.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageRule.contains(event.mouseButton.x, event.mouseButton.y))
							{
								clickedPos.x = event.mouseButton.x;
								clickedPos.y = event.mouseButton.y;
							}
							break;
						}
						break;
					case SETTING_BUTTON_FROM_GAME_PAGE:
						switch (settingPage)
						{
						case SETTING_PAGE_LOGIC:
							if (ButtonRectTurnOff.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSave.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectLoad.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectHome.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectBGMVolumeSubstruct.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectBGMVolumePlus.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectBGMVolumeTurn.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSEVolumeSubstruct.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSEVolumePlus.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSEVolumeTurn.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageLogic.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageRule.contains(event.mouseButton.x, event.mouseButton.y))
							{
								clickedPos.x = event.mouseButton.x;
								clickedPos.y = event.mouseButton.y;
							}
							else if (ButtonRectBGMSlider.contains(event.mouseButton.x, event.mouseButton.y))
								BGMSliderClicked = true;
							else if (ButtonRectSESlider.contains(event.mouseButton.x, event.mouseButton.y))
								SESliderClicked = true;
							else if (ButtonRectBGMStripe.contains(event.mouseButton.x, event.mouseButton.y))
							{
								musicVolume = (event.mouseButton.x - POP_WINDOW_X - BUTTON_BGM_STRIPE_X) * (float)100 / BUTTON_VOLUME_STRIPE_WIDTH;
								BGMSliderClicked = true;
							}
							else if (ButtonRectSEStripe.contains(event.mouseButton.x, event.mouseButton.y))
							{
								soundVolume = (event.mouseButton.x - POP_WINDOW_X - BUTTON_SE_STRIPE_X) * (float)100 / BUTTON_VOLUME_STRIPE_WIDTH;
								SESliderClicked = true;
							}
							break;
						case SETTING_PAGE_RULE:
							if (ButtonRectTurnOff.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageLogic.contains(event.mouseButton.x, event.mouseButton.y) ||
								ButtonRectSettingPageRule.contains(event.mouseButton.x, event.mouseButton.y))
							{
								clickedPos.x = event.mouseButton.x;
								clickedPos.y = event.mouseButton.y;
							}
							break;
						}
						break;
					default:
						if (ButtonRectYes.contains(event.mouseButton.x, event.mouseButton.y))
						{
							clickedPos.x = event.mouseButton.x;
							clickedPos.y = event.mouseButton.y;
						}
						else if (ButtonRectNo.contains(event.mouseButton.x, event.mouseButton.y) || ButtonRectTurnOff.contains(event.mouseButton.x, event.mouseButton.y))
						{
							clickedPos.x = event.mouseButton.x;
							clickedPos.y = event.mouseButton.y;
						}
						break;
					}
				}
				break;
			case Event::EventType::MouseMoved:
				if (BGMSliderClicked && musicVolume >= 0 && musicVolume <= 100)
				{
					musicVolume = (event.mouseMove.x - POP_WINDOW_X - BUTTON_BGM_STRIPE_X) * (float)100 / BUTTON_VOLUME_STRIPE_WIDTH;
					if (musicVolume < 0)
						musicVolume = 0;
					else if (musicVolume > 100)
						musicVolume = 100;

					if (!isMusicOn)
					{
						isMusicOn = true;
						StartPageBKMusic.play();
					}

					StartPageBKMusic.setVolume(musicVolume);
					GamePageBKMusic.setVolume(musicVolume);
				}

				if (SESliderClicked && soundVolume >= 0 && soundVolume <= 100)
				{
					soundVolume = (event.mouseMove.x - POP_WINDOW_X - BUTTON_SE_STRIPE_X) * (float)100 / BUTTON_VOLUME_STRIPE_WIDTH;
					if (soundVolume < 0)
						soundVolume = 0;
					else if (soundVolume > 100)
						soundVolume = 100;

					if (!isSoundOn)
					{
						isSoundOn = true;
					}

					soundButton.setVolume(soundVolume);
					soundPiece.setVolume(soundVolume);
				}
				break;
			case Event::EventType::MouseWheelScrolled:
				if ((lastClickState == SETTING_BUTTON_FROM_START_PAGE || lastClickState == SETTING_BUTTON_FROM_GAME_PAGE) && settingPage == SETTING_PAGE_RULE)
				{
					ruleAdjustment -= (int)(event.mouseWheelScroll.delta * 50);

					if (RULE_SHOW_HEIGHT + ruleAdjustment >= RULE_HEIGHT)
						ruleAdjustment = RULE_HEIGHT - RULE_SHOW_HEIGHT;

					if (ruleAdjustment <= 0)
						ruleAdjustment = 0;
				}
				break;
			case Event::EventType::MouseButtonReleased:
				if (event.mouseButton.button == Mouse::Left)
				{
					switch (lastClickState)
					{
					case SETTING_BUTTON_FROM_START_PAGE:
						if (ButtonRectTurnOff.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							noClicked = true;
						}

						if (ButtonRectSettingPageLogic.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							settingPage = SETTING_PAGE_LOGIC;
						}

						if (ButtonRectSettingPageRule.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							if (settingPage != SETTING_PAGE_RULE)
								ruleAdjustment = 0;

							settingPage = SETTING_PAGE_RULE;
						}

						if (ButtonRectBGMVolumeSubstruct.contains(clickedPos.x, clickedPos.y) && musicVolume > 0)
						{
							if (isSoundOn)
								soundButton.play();

							if (!isMusicOn)
							{
								isMusicOn = true;
								StartPageBKMusic.play();
							}

							musicVolume--;
							StartPageBKMusic.setVolume(musicVolume);
							GamePageBKMusic.setVolume(musicVolume);
						}

						if (ButtonRectBGMVolumePlus.contains(clickedPos.x, clickedPos.y) && musicVolume < 100)
						{
							if (isSoundOn)
								soundButton.play();

							if (!isMusicOn)
							{
								isMusicOn = true;
								StartPageBKMusic.play();
							}

							musicVolume++;
							StartPageBKMusic.setVolume(musicVolume);
							GamePageBKMusic.setVolume(musicVolume);
						}

						if (ButtonRectSEVolumeSubstruct.contains(clickedPos.x, clickedPos.y) && soundVolume > 0)
						{
							if (isSoundOn)
								soundButton.play();
							else
							{
								isSoundOn = true;
								soundButton.play();
							}

							soundVolume--;
							soundButton.setVolume(soundVolume);
							soundPiece.setVolume(soundVolume);
						}

						if (ButtonRectSEVolumePlus.contains(clickedPos.x, clickedPos.y) && soundVolume < 100)
						{
							if (isSoundOn)
								soundButton.play();
							else
							{
								isSoundOn = true;
								soundButton.play();
							}

							soundVolume++;
							soundButton.setVolume(soundVolume);
							soundPiece.setVolume(soundVolume);
						}

						if (ButtonRectBGMVolumeTurn.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							if (isMusicOn)
							{
								isMusicOn = false;
								StartPageBKMusic.pause();
							}
							else
							{
								isMusicOn = true;
								StartPageBKMusic.play();
							}
						}

						if (ButtonRectSEVolumeTurn.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								isSoundOn = false;
							else
							{
								isSoundOn = true;
								soundButton.play();
							}
						}

						if (BGMSliderClicked)
						{
							if (isSoundOn)
								soundButton.play();

							BGMSliderClicked = false;
						}

						if (SESliderClicked)
						{
							if (isSoundOn)
								soundButton.play();

							SESliderClicked = false;
						}

						break;
					case SETTING_BUTTON_FROM_GAME_PAGE:
						if (ButtonRectTurnOff.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							noClicked = true;
						}

						if (ButtonRectSave.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							gameState = SAVE_PAGE;
						}

						if (ButtonRectLoad.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							gameState = LOAD_PAGE;
						}

						if (ButtonRectHome.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							lastClickState = HOME_BUTTON;
						}

						if (ButtonRectSettingPageLogic.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							settingPage = SETTING_PAGE_LOGIC;
						}

						if (ButtonRectSettingPageRule.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							if (settingPage != SETTING_PAGE_RULE)
								ruleAdjustment = 0;

							settingPage = SETTING_PAGE_RULE;
						}

						if (ButtonRectBGMVolumeSubstruct.contains(clickedPos.x, clickedPos.y) && musicVolume > 0)
						{
							if (isSoundOn)
								soundButton.play();

							if (!isMusicOn)
							{
								isMusicOn = true;
								StartPageBKMusic.play();
							}

							musicVolume--;
							StartPageBKMusic.setVolume(musicVolume);
							GamePageBKMusic.setVolume(musicVolume);
						}

						if (ButtonRectBGMVolumePlus.contains(clickedPos.x, clickedPos.y) && musicVolume < 100)
						{
							if (isSoundOn)
								soundButton.play();

							if (!isMusicOn)
							{
								isMusicOn = true;
								StartPageBKMusic.play();
							}

							musicVolume++;
							StartPageBKMusic.setVolume(musicVolume);
							GamePageBKMusic.setVolume(musicVolume);
						}

						if (ButtonRectSEVolumeSubstruct.contains(clickedPos.x, clickedPos.y) && soundVolume > 0)
						{
							if (isSoundOn)
								soundButton.play();
							else
							{
								isSoundOn = true;
								soundButton.play();
							}

							soundVolume--;
							soundButton.setVolume(soundVolume);
							soundPiece.setVolume(soundVolume);
						}

						if (ButtonRectSEVolumePlus.contains(clickedPos.x, clickedPos.y) && soundVolume < 100)
						{
							if (isSoundOn)
								soundButton.play();
							else
							{
								isSoundOn = true;
								soundButton.play();
							}

							soundVolume++;
							soundButton.setVolume(soundVolume);
							soundPiece.setVolume(soundVolume);
						}

						if (ButtonRectBGMVolumeTurn.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							if (isMusicOn)
							{
								isMusicOn = false;
								GamePageBKMusic.pause();
							}
							else
							{
								isMusicOn = true;
								GamePageBKMusic.play();
							}
						}

						if (ButtonRectSEVolumeTurn.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								isSoundOn = false;
							else
							{
								isSoundOn = true;
								soundButton.play();
							}
						}

						if (BGMSliderClicked)
						{
							if (isSoundOn)
								soundButton.play();

							BGMSliderClicked = false;
						}

						if (SESliderClicked)
						{
							if (isSoundOn)
								soundButton.play();

							SESliderClicked = false;
						}
						break;
					default:
						if (ButtonRectYes.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							yesClicked = true;
						}
						else if (ButtonRectNo.contains(clickedPos.x, clickedPos.y) || ButtonRectTurnOff.contains(clickedPos.x, clickedPos.y))
						{
							if (isSoundOn)
								soundButton.play();

							noClicked = true;
						}
						break;
					}
					clickedPos = originPos;
				}
				break;
			}
			break;
		case SAVE_PAGE:
			switch (event.type)
			{
			case Event::MouseButtonPressed:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectBack.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLOne.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLTwo.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLThree.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLFour.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLFive.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLSix.contains(event.mouseButton.x, event.mouseButton.y))
					{
						clickedPos.x = event.mouseButton.x;
						clickedPos.y = event.mouseButton.y;
					}
				}
				break;
			case Event::MouseButtonReleased:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectBack.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();
						
						gameState = GAME_PAUSED_PAGE;
					}

					if (ButtonRectSLOne.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						in.open("save 1.txt");
						if (!in)
							save("save 1.txt");
						else
						{
							in.close();
							//
						}
					}

					if (ButtonRectSLTwo.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						in.open("save 2.txt");
						if (!in)
							save("save 2.txt");
						else
						{
							in.close();
							//
						}
					}

					if (ButtonRectSLThree.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						in.open("save 3.txt");
						if (!in)
							save("save 3.txt");
						else
						{
							in.close();
							//
						}
					}

					if (ButtonRectSLFour.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						in.open("save 4.txt");
						if (!in)
							save("save 4.txt");
						else
						{
							in.close();
							//
						}
					}

					if (ButtonRectSLFive.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						in.open("save 5.txt");
						if (!in)
							save("save 5.txt");
						else
						{
							in.close();
							//
						}
					}

					if (ButtonRectSLSix.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						in.open("save 6.txt");
						if (!in)
							save("save 6.txt");
						else
						{
							in.close();
							//
						}
					}

					clickedPos = originPos;
				}
			}
			break;
		case LOAD_PAGE:
			switch (event.type)
			{
			case Event::MouseButtonPressed:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectBack.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLOne.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLTwo.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLThree.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLFour.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLFive.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectSLSix.contains(event.mouseButton.x, event.mouseButton.y))
					{
						clickedPos.x = event.mouseButton.x;
						clickedPos.y = event.mouseButton.y;
					}
				}
				break;
			case Event::MouseButtonReleased:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectBack.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						gameState = GAME_PAUSED_PAGE;
					}

					if (ButtonRectSLOne.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						load("save 1.txt");
					}

					if (ButtonRectSLTwo.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						load("save 2.txt");
					}

					if (ButtonRectSLThree.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						load("save 3.txt");
					}

					if (ButtonRectSLFour.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						load("save 4.txt");
					}

					if (ButtonRectSLFive.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						load("save 5.txt");
					}

					if (ButtonRectSLSix.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						load("save 6.txt");
					}

					clickedPos = originPos;
				}
			}
			break;
		case GAME_OVER_PAGE:
			switch (event.type)
			{
			case Event::MouseButtonPressed:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectRestart.contains(event.mouseButton.x, event.mouseButton.y) ||
						ButtonRectExit.contains(event.mouseButton.x, event.mouseButton.y))
					{
						clickedPos.x = event.mouseButton.x;
						clickedPos.y = event.mouseButton.y;
					}
				}
				break;
			case Event::MouseButtonReleased:
				if (event.mouseButton.button == Mouse::Left)
				{
					if (ButtonRectRestart.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						chess.initPiece();
						formerChess = chess;
						gameState = GAME_PAGE;
						gameOver = false;
						lastClickState = PIECE;

						break;
					}

					if (ButtonRectExit.contains(clickedPos.x, clickedPos.y))
					{
						if (isSoundOn)
							soundButton.play();

						window.close();
						gameQuit = true;

						break;
					}
					clickedPos = originPos;
				}
				break;
			case Event::KeyReleased:
				break;
			}
			break;
		default:
			break;
		}
	}
}

void Game::gameLogic()
{
	switch (gameState)
	{
	case START_PAGE:
		break;
	case GAME_PAGE:
		switch (lastClickState)
		{
		case PIECE:
			gameOver = chess.isGameOver();

			//��һ�ε��ʱ
			if (chess.firstClick && !chess.secondClick)
			{
				chess.stepBeforeAttacker = chess.Attacker;
				//��������λ��û������
				if (!chess.cb.isPiecePosUsed[chess.chosenPos.x][chess.chosenPos.y])
				{
					chess.firstClick = false;
					chess.chosenPos = chess.stepBeforeChosenPos;
					chess.Attacker = chess.stepBeforeAttacker;
					break;
				}

				for (int i = 0; i < 32; i++)
				{
					if (chess.piece[i].isDeath)
						continue;

					if (chess.piece[i].piecePosition == chess.chosenPos)
					{
						chess.Attacker = &chess.piece[i];
						break;
					}
				}

				//������ǵ�һ�ε��
				if (!chess.isClicked)
					chess.isClicked = true;

				//����������δ����
				if (!chess.Attacker->isOpened)
				{
					chess.pieceState = WAIT_4_OPEN;
					break;
				}
				//�����������ѷ�����Ϊ�ҷ���Ӫ����
				else if (chess.Attacker->bloc == chess.bloc)
				{
					chess.pieceState = WAIT_4_ATTACK;
					break;
				}
				//�����������ѷ����������ҷ���Ӫ���ӣ�����δ�����
				else
				{
					chess.firstClick = false;
					chess.chosenPos = chess.stepBeforeChosenPos;
					chess.Attacker = chess.stepBeforeAttacker;
					break;
				}
			}

			//�ڶ��ε����
			if (chess.firstClick && chess.secondClick)
			{
				//�����һ�ε�������ǵȴ�����״̬
				if (chess.pieceState == WAIT_4_OPEN)
				{
					//����ڶ��ε�����󲻴������ӣ���Ϊδ����ڶ��Σ� ��
					if (!chess.cb.isPiecePosUsed[chess.chosenPos2.x][chess.chosenPos2.y])
					{
						chess.secondClick = false;
						chess.chosenPos2 = formerChess.chosenPos2;
						break;
					}

					for (int i = 0; i < 32; i++)
					{
						if (chess.piece[i].isDeath)
							continue;

						if (chess.piece[i].piecePosition == chess.chosenPos2)
						{
							chess.Defencer = &chess.piece[i];
							break;
						}
					}

					//�����һ�ε�������ǵȴ�����״̬���ҵڶ��ε�����������Ǹö��� ��
					if (chess.chosenPos2 == chess.Attacker->piecePosition)
					{
						formerChess = chess;

						chess.Attacker->pieceOpen(&chess.tPiece);

						//�������ȫ����һ������������
						if (chess.firstOpen)
						{
							chess.bloc = chess.Attacker->bloc;
							chess.firstOpen = false;
						}

						chess.pieceState = WAIT_4_NONE;
						chess.firstClick = false;
						chess.secondClick = false;

						if (chess.bloc == c_BLACK)
							chess.bloc = c_RED;
						else
							chess.bloc = c_BLACK;

						break;
					}
					//����ڶ��ε�������ǵ�һ�ε���������ǵ�ǰ��Ӫ���ӻ�δ�������ӣ��ӱ��εڶ��ε��Ϊ��һ�ε������
					else if (chess.bloc == chess.Defencer->bloc || !chess.Defencer->isOpened)
					{
						chess.secondClick = false;
						chess.chosenPos = chess.chosenPos2;
						chess.Attacker = chess.Defencer;
						chess.chosenPos2 = formerChess.chosenPos2;

						break;
					}
					//����ڶ��ε�������ǵ�һ�ε�������Ҳ����ҷ���Ӫ���ӣ���Ϊδ����ڶ��Σ� ��
					else
					{
						chess.secondClick = false;
						chess.chosenPos2 = formerChess.chosenPos2;
						break;
					}
				}

				//�����һ�ε�������ǵȴ�����״̬
				if (chess.pieceState == WAIT_4_ATTACK)
				{
					for (int i = 0; i < 32; i++)
					{
						if (chess.piece[i].isDeath)
							continue;

						if (chess.piece[i].piecePosition == chess.chosenPos2)
						{
							chess.Defencer = &chess.piece[i];
							break;
						}
					}

					//�����һ�ε������͵ڶ��ε��������ͬһ���󣬣��ӱ��εڶ��ε��Ϊ��һ�ε������
					if (chess.Attacker->piecePosition == chess.chosenPos2)
					{
						chess.secondClick = false;
						chess.chosenPos = chess.chosenPos2;
						chess.Attacker = chess.Defencer;
						chess.chosenPos2 = formerChess.chosenPos2;

						break;
					}

					//����ڶ��ε��λ�÷����ƶ������� ��
					if (chess.cb.pieceMove(chess.Attacker, chess.chosenPos2))
					{
						formerChess = chess;

						chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x][chess.Attacker->piecePosition.y] = false;
						chess.cb.isPiecePosUsed[chess.chosenPos2.x][chess.chosenPos2.y] = true;
						chess.Attacker->piecePosition = chess.chosenPos2;

						chess.pieceState = WAIT_4_NONE;
						chess.firstClick = false;
						chess.secondClick = false;

						if (chess.bloc == c_BLACK)
							chess.bloc = c_RED;
						else
							chess.bloc = c_BLACK;

						break;
					}
					//�����һ�ε���������ڣ��ҵڶ��ε��λ�÷��Ϲ�������
					else if (chess.Attacker->pieceType != c_CANNON &&
						((abs(chess.Attacker->piecePosition.x - chess.chosenPos2.x) == 1 && chess.Attacker->piecePosition.y - chess.chosenPos2.y == 0) ||
						(abs(chess.Attacker->piecePosition.y - chess.chosenPos2.y) == 1 && chess.Attacker->piecePosition.x - chess.chosenPos2.x == 0)))
					{
						//����ڶ��ε�������Ѿ������� 
						if (chess.Defencer->isOpened)
						{
							//����ڶ��ε�������Ѿ������Ҳ��ǵ�һ�ε��������Ӫ ��
							if (chess.Defencer->bloc != chess.bloc)
							{
								formerChess = chess;
								chess.cb.pieceCompare(chess.Attacker, chess.Defencer, chess.lastDeadPiece, &chess.lastDeadPieceNum, &chess.redPrice, &chess.blackPrice);

								chess.pieceState = WAIT_4_NONE;
								chess.firstClick = false;
								chess.secondClick = false;

								if (chess.bloc == c_BLACK)
									chess.bloc = c_RED;
								else
									chess.bloc = c_BLACK;

								break;
							}
							//����ڶ��ε�������ѷ������ǵ�һ�ε��������Ӫ���ӵڶ��ε��Ϊ��һ�ε������
							else
							{
								chess.secondClick = false;

								chess.chosenPos = chess.chosenPos2;
								for (int i = 0; i < 32; i++)
								{
									if (chess.piece[i].isDeath)
										continue;

									if (chess.piece[i].piecePosition == chess.chosenPos)
									{
										chess.Attacker = &chess.piece[i];
										break;
									}
								}

								if (!chess.Attacker->isOpened)
								{
									chess.pieceState = WAIT_4_OPEN;
								}
								else if (chess.Attacker->bloc == chess.bloc)
								{
									chess.pieceState = WAIT_4_ATTACK;
								}

								chess.chosenPos2 = formerChess.chosenPos2;

								break;
							}
						}
						//����ڶ��ε������δ����������Ӫ���ҷ���ͬ ��
						else if (chess.Defencer->bloc != chess.bloc)
						{
							formerChess = chess;

							chess.Defencer->pieceOpen(&chess.tPiece);
							chess.cb.pieceCompare(chess.Attacker, chess.Defencer, chess.lastDeadPiece, &chess.lastDeadPieceNum, &chess.redPrice, &chess.blackPrice);

							chess.pieceState = WAIT_4_NONE;
							chess.firstClick = false;
							chess.secondClick = false;

							if (chess.bloc == c_BLACK)
								chess.bloc = c_RED;
							else
								chess.bloc = c_BLACK;

							break;
						}
						//����ڶ��ε������δ������Ϊ�ҷ���Ӫ����Ϊ�����ڶ��ε������ ��
						else
						{
							formerChess = chess;

							chess.Defencer->pieceOpen(&chess.tPiece);

							chess.pieceState = WAIT_4_NONE;
							chess.firstClick = false;
							chess.secondClick = false;

							if (chess.bloc == c_BLACK)
								chess.bloc = c_RED;
							else
								chess.bloc = c_BLACK;

							break;
						}
					}
					//�����һ�ε���������ڣ����ҵڶ��ε��λ���ں�������������һ��λ��
					else if (chess.Attacker->pieceType == c_CANNON &&
						((abs(chess.Attacker->piecePosition.x - chess.chosenPos2.x) > 1 && chess.Attacker->piecePosition.y == chess.chosenPos2.y) ||
						(abs(chess.Attacker->piecePosition.y - chess.chosenPos2.y) > 1 && chess.Attacker->piecePosition.x == chess.chosenPos2.x)))
					{
						bool isAbleToAttack = true;

						//����ڶ��ε����λ��û�����ӣ���Ϊδ����ڶ��Σ� ��
						if (!chess.cb.isPiecePosUsed[chess.chosenPos2.x][chess.chosenPos2.y])
						{
							chess.secondClick = false;
							chess.chosenPos2 = formerChess.chosenPos2;
							break;
						}
						//����ڶ��ε��������Χû���ڼ�
						else if ((chess.Defencer->piecePosition.x < chess.Attacker->piecePosition.x && !chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x - 1][chess.Attacker->piecePosition.y]) ||
							(chess.Defencer->piecePosition.x > chess.Attacker->piecePosition.x && !chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x + 1][chess.Attacker->piecePosition.y]) ||
							(chess.Defencer->piecePosition.y < chess.Attacker->piecePosition.y && !chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x][chess.Attacker->piecePosition.y - 1]) ||
							(chess.Defencer->piecePosition.y > chess.Attacker->piecePosition.y && !chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x][chess.Attacker->piecePosition.y + 1]))
						{
							isAbleToAttack = false;
						}
						//����ڶ��ε�������ڵ�һ�ε���������
						else if (chess.Defencer->piecePosition.x < chess.Attacker->piecePosition.x && chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x - 1][chess.Attacker->piecePosition.y])
						{
							//�������Ϊ������ֱ�ӿ��Թ���
							if (chess.Attacker->piecePosition.x - chess.Defencer->piecePosition.x == 2)
							{
								isAbleToAttack = true;
							}

							//���������ڶ������ж����ε��֮����û�и��������
							for (int i = chess.Defencer->piecePosition.x + 1; i < chess.Attacker->piecePosition.x - 1; i++)
							{
								if (chess.cb.isPiecePosUsed[i][chess.Attacker->piecePosition.y])
								{
									isAbleToAttack = false;
									break;
								}
							}
						}
						//����ڶ��ε�������ڵ�һ�ε�������Ҳ�
						else if (chess.Defencer->piecePosition.x > chess.Attacker->piecePosition.x && chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x + 1][chess.Attacker->piecePosition.y])
						{
							//�������Ϊ������ֱ�ӿ��Թ���
							if (chess.Defencer->piecePosition.x - chess.Attacker->piecePosition.x == 2)
							{
								isAbleToAttack = true;
							}

							//���������ڶ������ж����ε��֮����û�и��������
							for (int i = chess.Attacker->piecePosition.x + 2; i < chess.Defencer->piecePosition.x; i++)
							{
								if (chess.cb.isPiecePosUsed[i][chess.Attacker->piecePosition.y])
								{
									isAbleToAttack = false;
									break;
								}
							}
						}
						//����ڶ��ε�������ڵ�һ�ε�������ϲ�
						else if (chess.Defencer->piecePosition.y < chess.Attacker->piecePosition.y && chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x][chess.Attacker->piecePosition.y - 1])
						{
							//�������Ϊ������ֱ�ӿ��Թ���
							if (chess.Attacker->piecePosition.y - chess.Defencer->piecePosition.y == 2)
							{
								isAbleToAttack = true;
							}

							//���������ڶ������ж����ε��֮����û�и��������
							for (int i = chess.Defencer->piecePosition.y + 1; i < chess.Attacker->piecePosition.y - 1; i++)
							{
								if (chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x][i])
								{
									isAbleToAttack = false;
									break;
								}
							}
						}
						//����ڶ��ε�������ڵ�һ�ε�������²�
						else if (chess.Defencer->piecePosition.y > chess.Attacker->piecePosition.y && chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x][chess.Attacker->piecePosition.y + 1])
						{
							//�������Ϊ������ֱ�ӿ��Թ���
							if (chess.Defencer->piecePosition.y - chess.Attacker->piecePosition.y == 2)
							{
								isAbleToAttack = true;
							}

							//���������ڶ������ж����ε��֮����û�и��������
							for (int i = chess.Attacker->piecePosition.y + 2; i < chess.Defencer->piecePosition.y; i++)
							{
								if (chess.cb.isPiecePosUsed[chess.Attacker->piecePosition.x][i])
								{
									isAbleToAttack = false;
									break;
								}
							}
						}

						//������Թ��� ��
						if (isAbleToAttack)
						{
							formerChess = chess;

							chess.Defencer->pieceOpen(&chess.tPiece);
							chess.cb.pieceCompare(chess.Attacker, chess.Defencer, chess.lastDeadPiece, &chess.lastDeadPieceNum, &chess.redPrice, &chess.blackPrice);

							chess.pieceState = WAIT_4_NONE;
							chess.firstClick = false;
							chess.secondClick = false;

							if (chess.bloc == c_BLACK)
								chess.bloc = c_RED;
							else
								chess.bloc = c_BLACK;

							break;
						}
						//������ܹ��� ��
						else
						{
							//����ڶ��ε����λ���ж������
							if (chess.cb.isPiecePosUsed[chess.chosenPos2.x][chess.chosenPos2.y])
							{
								//����ڶ��ε�������Ѿ�����
								if (chess.Defencer->isOpened)
								{
									//����ڶ��ε�������Ѿ������Ҳ��ǵ�һ�ε��������Ӫ����δ����ڶ��Σ� ��
									if (chess.Defencer->bloc != chess.bloc)
									{
										chess.secondClick = false;
										chess.chosenPos2 = formerChess.chosenPos2;
										break;
									}
									//����ڶ��ε�������ѷ������ǵ�һ�ε��������Ӫ���ӵڶ��ε��Ϊ��һ�ε������
									else
									{
										chess.secondClick = false;
										chess.chosenPos = chess.chosenPos2;
										chess.Attacker = chess.Defencer;
										chess.pieceState = WAIT_4_ATTACK;

										chess.chosenPos2 = formerChess.chosenPos2;

										break;
									}
								}
								//����ڶ��ε������δ�������ӵڶ��ε��Ϊ��һ�ε������
								else
								{
									chess.secondClick = false;
									chess.chosenPos = chess.chosenPos2;
									chess.Attacker = chess.Defencer;
									chess.pieceState = WAIT_4_OPEN;

									chess.chosenPos2 = formerChess.chosenPos2;

									break;
								}
							}
							//����ڶ��ε����λ��û�ж�����ڣ���δ����ڶ��Σ� ��
							else
							{
								chess.secondClick = false;
								chess.chosenPos2 = formerChess.chosenPos2;
								break;
							}
						}
					}
					//����ڶ��ε����λ�üȲ����ƶ���Ҳ���ܱ�����
					else
					{
						//����ڶ��ε����λ���ж������
						if (chess.cb.isPiecePosUsed[chess.chosenPos2.x][chess.chosenPos2.y])
						{
							//����ڶ��ε�������Ѿ�����
							if (chess.Defencer->isOpened)
							{
								//����ڶ��ε�������Ѿ������Ҳ��ǵ�һ�ε��������Ӫ����δ����ڶ��Σ� ��
								if (chess.Defencer->bloc != chess.bloc)
								{
									chess.secondClick = false;
									chess.chosenPos2 = formerChess.chosenPos2;
									break;
								}
								//����ڶ��ε�������ѷ������ǵ�һ�ε��������Ӫ���ӵڶ��ε��Ϊ��һ�ε������
								else
								{
									chess.secondClick = false;
									chess.chosenPos = chess.chosenPos2;
									chess.Attacker = chess.Defencer;
									chess.pieceState = WAIT_4_ATTACK;

									chess.chosenPos2 = formerChess.chosenPos2;

									break;
								}
							}
							//����ڶ��ε������δ�������ӵڶ��ε��Ϊ��һ�ε������
							else
							{
								chess.secondClick = false;
								chess.chosenPos = chess.chosenPos2;
								chess.Attacker = chess.Defencer;
								chess.pieceState = WAIT_4_OPEN;

								chess.chosenPos2 = formerChess.chosenPos2;

								break;
							}
						}
						//����ڶ��ε����λ��û�ж�����ڣ���δ����ڶ��Σ� ��
						else
						{
							chess.secondClick = false;
							chess.chosenPos2 = formerChess.chosenPos2;
							break;
						}
					}
				}
			}
			break;
		case REGRET_BUTTON:
		case SURRENDER_BUTTON:
		case TIE_BUTTON:
			gameState = GAME_PAUSED_PAGE;
			break;
		case SETTING_BUTTON_FROM_GAME_PAGE:
			gameState = GAME_PAUSED_PAGE;
			break;
		default:
			break;
		}

		if (gameOver)
			gameState = GAME_OVER_PAGE;
		break;

	case GAME_PAUSED_PAGE:
		switch (lastClickState)
		{
		case REGRET_BUTTON:
			if (yesClicked)
			{
				chess = formerChess;
				chess.firstClick = false;
				chess.secondClick = false;

				lastClickState = PIECE;
				gameState = GAME_PAGE;
				yesClicked = false;
			}
			else if (noClicked)
			{
				lastClickState = PIECE;
				gameState = GAME_PAGE;
				noClicked = false;
			}
			break;
		case TIE_BUTTON:
			if (yesClicked)
			{
				chess.winner = -1;
				gameOver = true;

				lastClickState = PIECE;
				gameState = GAME_OVER_PAGE;
				yesClicked = false;
			}
			else if (noClicked)
			{
				lastClickState = PIECE;
				gameState = GAME_PAGE;
				noClicked = false;
			}
			break;
		case SURRENDER_BUTTON:
			if (yesClicked)
			{
				if (chess.bloc == c_RED)
				{
					chess.winner = c_BLACK;
					gameOver = true;
				}
				else
				{
					chess.winner = c_RED;
					gameOver = true;
				}

				lastClickState = PIECE;
				gameState = GAME_OVER_PAGE;
				yesClicked = false;
			}
			else if (noClicked)
			{
				lastClickState = PIECE;
				gameState = GAME_PAGE;
				noClicked = false;
			}
			break;
		case SETTING_BUTTON_FROM_START_PAGE:
			if (noClicked)
			{
				settingPage = SETTING_PAGE_LOGIC;
				lastClickState = PIECE;
				gameState = START_PAGE;
				ruleAdjustment = 0;
				noClicked = false;
			}
			break;
		case SETTING_BUTTON_FROM_GAME_PAGE:
			if (noClicked)
			{
				settingPage = SETTING_PAGE_LOGIC;
				lastClickState = PIECE;
				gameState = GAME_PAGE;
				ruleAdjustment = 0;
				noClicked = false;
			}
			break;
		case HOME_BUTTON:
			if (yesClicked)
			{
				gameState = START_PAGE;
				lastClickState = PIECE;
				yesClicked = false;

				if (isMusicOn)
				{
					GamePageBKMusic.stop();
					StartPageBKMusic.play();
					StartPageBKMusic.setLoop(true);
				}
			}
			else if (noClicked)
			{
				lastClickState = SETTING_BUTTON_FROM_GAME_PAGE;
				noClicked = false;
			}
			break;
		}
		break;
	case GAME_OVER_PAGE:
		break;
	default:
		break;
	}
}

void Game::gameDraw()
{
	int grid_x = 0;
	int grid_y = 0;
	std::stringstream ss;
	switch (gameState)
	{
	case START_PAGE:
		window.clear(Color::Color(255, 255, 255, 255));

		spStartPage.setPosition(0, 0);
		window.draw(spStartPage);

		drawButtons(gameState);

		window.display();
		break;

	case GAME_PAGE:
		window.clear();

		gamePageDraw();

		window.display();
		break;

	case GAME_PAUSED_PAGE:
		window.clear();

		if (lastClickState != SETTING_BUTTON_FROM_START_PAGE)
			gamePageDraw();
		else
		{
			spStartPage.setPosition(0, 0);
			window.draw(spStartPage);

			drawButtons(START_PAGE);
		}

		spPopWindow.setPosition(POP_WINDOW_X, POP_WINDOW_Y);
		window.draw(spPopWindow);

		switch (lastClickState)
		{
		case REGRET_BUTTON:
			spAcceptWord.setTexture(tAcceptRetractWord);
			spAcceptWord.setPosition(ACCEPT_RETRACT_WORD_X + POP_WINDOW_X, ACCEPT_RETRACT_WORD_Y + POP_WINDOW_Y);
			window.draw(spAcceptWord);

			drawButtons(gameState);

			break;

		case TIE_BUTTON:
			spAcceptWord.setTexture(tAcceptTieWord);
			spAcceptWord.setPosition(ACCEPT_TIE_WORD_X + POP_WINDOW_X, ACCEPT_TIE_WORD_Y + POP_WINDOW_Y);
			window.draw(spAcceptWord);

			drawButtons(gameState);

			break;

		case SURRENDER_BUTTON:
			spAcceptWord.setTexture(tToSurrenderWord);
			spAcceptWord.setPosition(TO_SURRENDER_WORD_X + POP_WINDOW_X, TO_SURRENDER_WORD_Y + POP_WINDOW_Y);
			window.draw(spAcceptWord);

			drawButtons(gameState);

			break;

		case SETTING_BUTTON_FROM_START_PAGE:
		case SETTING_BUTTON_FROM_GAME_PAGE:
			switch (settingPage)
			{
			case SETTING_PAGE_LOGIC:
				spBGMWord.setPosition(BGM_WORD_X + POP_WINDOW_X, BGM_WORD_Y + POP_WINDOW_Y);
				window.draw(spBGMWord);
				spSEWord.setPosition(SE_WORD_X + POP_WINDOW_X, SE_WORD_Y + POP_WINDOW_Y);
				window.draw(spSEWord);

				ss.str("");
				text.setCharacterSize(36);
				text.setFillColor(Color::Color(0, 0, 0, 255));
				if (isMusicOn)
				{
					ss << (int)musicVolume;
					text.setString(ss.str());
				}
				else
				{
					text.setString(L"��");
				}
				text.setPosition(BGM_VOLUME_VALUE_X + POP_WINDOW_X, BGM_VOLUME_VALUE_Y + POP_WINDOW_Y);
				text.setOrigin(0, 0);
				window.draw(text);

				ss.str("");
				text.setCharacterSize(36);
				text.setFillColor(Color::Color(0, 0, 0, 255));
				if (isSoundOn)
				{
					ss << (int)soundVolume;
					text.setString(ss.str());
				}
				else
				{
					text.setString(L"��");
				}
				text.setPosition(SE_VOLUME_VALUE_X + POP_WINDOW_X, SE_VOLUME_VALUE_Y + POP_WINDOW_Y);
				text.setOrigin(0, 0);
				window.draw(text);
				break;
			case SETTING_PAGE_RULE:
				spRule.setTextureRect(IntRect(0, ruleAdjustment, RULE_WIDTH, RULE_SHOW_HEIGHT));
				spRule.setPosition(RULE_POS_X + POP_WINDOW_X, RULE_POS_Y + POP_WINDOW_Y);
				window.draw(spRule);
				break;
			}
			drawButtons(gameState);
			break;

		case HOME_BUTTON:
			spBackHomeWord.setPosition(BACK_HOME_WORD_X + POP_WINDOW_X, BACK_HOME_WORD_Y + POP_WINDOW_Y);
			window.draw(spBackHomeWord);

			drawButtons(gameState);
			break;
		}
		window.display();
		break;
	case SAVE_PAGE:
		window.clear();

		spBigPopWindow.setPosition(BIG_POP_WINDOW_X, BIG_POP_WINDOW_Y);
		window.draw(spBigPopWindow);

		spSaveWord.setPosition(SL_WORD_X, SL_WORD_Y);
		window.draw(spSaveWord);

		drawButtons(gameState);

		drawSaveWord("save 1.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y, 
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 2.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y, 
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 3.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y, 
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 4.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y, 
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 5.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y, 
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 6.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y, 
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y);

		window.display();
		break;
	case LOAD_PAGE:
		window.clear();
		spBigPopWindow.setPosition(BIG_POP_WINDOW_X, BIG_POP_WINDOW_Y);
		window.draw(spBigPopWindow);

		spLoadWord.setPosition(SL_WORD_X, SL_WORD_Y);
		window.draw(spLoadWord);

		drawButtons(gameState);

		drawSaveWord("save 1.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y,
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 2.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y,
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 3.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y,
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_1 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 4.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y,
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_1 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 5.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y,
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_2 + BIG_POP_WINDOW_Y);
		drawSaveWord("save 6.txt", SL_DETAIL_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_DETAIL_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y,
			SL_TIME_WORD_X_IN_RECTANGLE + SL_RECTANGLE_X_2 + BIG_POP_WINDOW_X, SL_TIME_WORD_Y_IN_RECTANGLE + SL_RECTANGLE_Y_3 + BIG_POP_WINDOW_Y);

		window.display();

		break;
	case GAME_OVER_PAGE:
		window.clear();

		gamePageDraw();

		spPopWindow.setPosition(POP_WINDOW_X, POP_WINDOW_Y);
		window.draw(spPopWindow);
		
		switch (chess.winner)
		{
		case c_RED:
			grid_y = 0;
			spWinnerWord.setPosition(WINNER_WORD_X + POP_WINDOW_X, WINNER_WORD_Y + POP_WINDOW_Y);
			break;
		case c_BLACK:
			grid_y = 1;
			spWinnerWord.setPosition(WINNER_WORD_X + POP_WINDOW_X, WINNER_WORD_Y + POP_WINDOW_Y);
			break;
		default:
			grid_y = 2;
			spWinnerWord.setPosition(TIE_WORD_X + POP_WINDOW_X, TIE_WORD_Y + POP_WINDOW_Y);
			break;
		}
		spWinnerWord.setTextureRect(IntRect(0, grid_y * WINNER_WORD_HEIGHT, WINNER_WORD_WIDTH, WINNER_WORD_HEIGHT));
		window.draw(spWinnerWord);

		drawButtons(gameState);

		window.display();
		break;
	default:
		break;
	}
}

void Game::gameRun()
{
	gameInit();
	while (!gameQuit)
	{
		gameInput();
		gameLogic();
		gameDraw();
	}
}